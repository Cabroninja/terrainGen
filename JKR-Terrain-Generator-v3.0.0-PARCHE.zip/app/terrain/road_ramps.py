from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from app.core.models import RoadRamp


@dataclass(slots=True)
class RoadRampResult:
    height: np.ndarray
    road_mask: np.ndarray
    issues: list[dict]
    summaries: list[dict]


def _smoothstep(value: np.ndarray) -> np.ndarray:
    t = np.clip(value, 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def _sample_height(height: np.ndarray, x: float, z: float) -> float:
    zi = int(np.clip(round(z), 0, height.shape[0] - 1))
    xi = int(np.clip(round(x), 0, height.shape[1] - 1))
    return float(height[zi, xi])


def _ramp_profile(
    progress: np.ndarray,
    total_length: float,
    start_height: float,
    end_height: float,
    start_landing: float,
    end_landing: float,
) -> np.ndarray:
    run_start = min(start_landing, total_length)
    run_end = max(run_start, total_length - end_landing)
    run_length = max(1e-6, run_end - run_start)
    t = np.clip((progress - run_start) / run_length, 0.0, 1.0)
    profile = start_height + (end_height - start_height) * t
    profile = np.where(progress <= run_start, start_height, profile)
    profile = np.where(progress >= run_end, end_height, profile)
    return profile.astype(np.float32)


def apply_road_ramps(source_height: np.ndarray, painted_roads: np.ndarray, ramps: list[RoadRamp]) -> RoadRampResult:
    """Apply explicit, bounded road ramps without changing terrain outside each corridor.

    The center corridor receives the exact longitudinal ramp height. The optional
    lateral shoulder blends that height back to the original terrain. Normal
    painted roads are copied unchanged and never modify height.
    """

    height = source_height.astype(np.float32, copy=True)
    road_mask = painted_roads.astype(np.uint8, copy=True)
    issues: list[dict] = []
    summaries: list[dict] = []
    map_length, map_width = height.shape

    for ramp in ramps:
        points = np.asarray([(point.x, point.z) for point in ramp.points], dtype=np.float32)
        vectors = points[1:] - points[:-1]
        segment_lengths = np.sqrt(np.sum(vectors * vectors, axis=1))
        total_length = float(segment_lengths.sum())
        if total_length <= 1e-6:
            issues.append({
                "severity": "error",
                "code": "road_ramp_zero_length",
                "message": f"La rampa «{ramp.label or ramp.id}» no tiene longitud útil.",
            })
            continue

        start_height = _sample_height(source_height, *points[0])
        end_height = _sample_height(source_height, *points[-1])
        delta_height = abs(end_height - start_height)
        available_run = max(0.0, total_length - ramp.start_landing - ramp.end_landing)
        required_run = delta_height * ramp.slope_ratio
        actual_ratio = available_run / delta_height if delta_height > 1e-6 else float("inf")
        valid = available_run + 1e-6 >= required_run
        if not valid:
            issues.append({
                "severity": "error",
                "code": "road_ramp_too_short",
                "message": (
                    f"La rampa «{ramp.label or ramp.id}» mide {total_length:.1f} bloques, "
                    f"pero necesita al menos {required_run + ramp.start_landing + ramp.end_landing:.1f} "
                    f"para mantener una pendiente 1:{ramp.slope_ratio:g}."
                ),
            })

        half_width = ramp.width / 2.0
        outer_radius = half_width + ramp.shoulder_width
        x0 = max(0, int(np.floor(points[:, 0].min() - outer_radius - 1)))
        x1 = min(map_width - 1, int(np.ceil(points[:, 0].max() + outer_radius + 1)))
        z0 = max(0, int(np.floor(points[:, 1].min() - outer_radius - 1)))
        z1 = min(map_length - 1, int(np.ceil(points[:, 1].max() + outer_radius + 1)))
        zz, xx = np.mgrid[z0:z1 + 1, x0:x1 + 1]
        gx = xx.astype(np.float32)
        gz = zz.astype(np.float32)
        best_distance_sq = np.full(gx.shape, np.inf, dtype=np.float32)
        best_progress = np.zeros(gx.shape, dtype=np.float32)
        cumulative = 0.0

        for index, ((ax, az), (vx, vz), segment_length) in enumerate(zip(points[:-1], vectors, segment_lengths, strict=True)):
            if segment_length <= 1e-6:
                continue
            denominator = float(segment_length * segment_length)
            t = np.clip(((gx - ax) * vx + (gz - az) * vz) / denominator, 0.0, 1.0)
            nearest_x = ax + t * vx
            nearest_z = az + t * vz
            distance_sq = (gx - nearest_x) ** 2 + (gz - nearest_z) ** 2
            closer = distance_sq < best_distance_sq
            best_distance_sq = np.where(closer, distance_sq, best_distance_sq)
            best_progress = np.where(closer, cumulative + t * segment_length, best_progress)
            cumulative += float(segment_length)

        distance = np.sqrt(best_distance_sq)
        affected = distance <= outer_radius + 1e-6
        center = distance <= half_width + 1e-6
        if not np.any(affected):
            continue

        target = _ramp_profile(
            best_progress,
            total_length,
            start_height,
            end_height,
            float(ramp.start_landing),
            float(ramp.end_landing),
        )
        if ramp.shoulder_width > 0:
            shoulder_t = (distance - half_width) / float(ramp.shoulder_width)
            influence = 1.0 - _smoothstep(shoulder_t)
        else:
            influence = center.astype(np.float32)
        influence = np.where(affected, np.clip(influence, 0.0, 1.0), 0.0).astype(np.float32)

        target_slice = height[z0:z1 + 1, x0:x1 + 1]
        # Each ramp is explicit and bounded: outside `affected`, source height is untouched.
        target_slice[:] = target_slice * (1.0 - influence) + target * influence

        road_slice = road_mask[z0:z1 + 1, x0:x1 + 1]
        road_value = 1 if ramp.road_type == "primary" else 2
        if road_value == 1:
            road_slice[center] = 1
        else:
            road_slice[center & (road_slice == 0)] = 2

        summaries.append({
            "id": ramp.id,
            "label": ramp.label,
            "length": round(total_length, 3),
            "start_height": round(start_height, 3),
            "end_height": round(end_height, 3),
            "height_difference": round(delta_height, 3),
            "minimum_ratio": ramp.slope_ratio,
            "actual_ratio": None if not np.isfinite(actual_ratio) else round(actual_ratio, 3),
            "valid": valid,
            "width": ramp.width,
            "shoulder_width": ramp.shoulder_width,
        })

    return RoadRampResult(height=height, road_mask=road_mask, issues=issues, summaries=summaries)

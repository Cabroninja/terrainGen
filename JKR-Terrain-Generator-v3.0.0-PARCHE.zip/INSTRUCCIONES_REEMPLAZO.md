# Instalación de JKR Terrain Generator v3.0.0

## Parche sobre v2.9.0

Coloca `JKR-Terrain-Generator-v3.0.0-PARCHE.zip` en la raíz del proyecto y ejecuta:

```bash
unzip -o JKR-Terrain-Generator-v3.0.0-PARCHE.zip
rm JKR-Terrain-Generator-v3.0.0-PARCHE.zip
docker compose down
docker compose up -d --build
docker compose logs --tail=100
```

Después realiza una recarga forzada del navegador (`Ctrl+F5`). Los proyectos anteriores siguen abriendo normalmente; la lista de rampas comienza vacía.

## Proyecto completo

Extrae `JKR-Terrain-Generator-v3.0.0-COMPLETO.zip` en una carpeta nueva y ejecuta `docker compose up -d --build`.

## Flujo de la rampa

1. Selecciona **Caminos**.
2. Cambia **Herramienta vial** a **Crear o editar rampa**.
3. Haz clic en el punto bajo.
4. Añade puntos siguiendo el recorrido y termina sobre la meseta.
5. Ajusta ancho, transición lateral, pendiente y descansos.
6. Pulsa **Finalizar rampa** cuando aparezca como válida.
7. Compila y revisa la Vista Minecraft.

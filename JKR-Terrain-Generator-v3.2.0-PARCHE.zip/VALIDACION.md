# Validación de la entrega v3.2.0

## Comandos ejecutados

```bash
python -m compileall -q app scripts tests
node --check app/static/app.js
node --check app/static/water-course-tool.js
node --check app/static/terrain-viewer.js
node --check app/static/voxel-viewer.js
python -m json.tool app/static/config-help.json
pytest -q
```

## Resultado

- 61 pruebas automáticas aprobadas.
- API de salud actualizada a v3.2.0.
- Proyectos anteriores sin `water_courses` compatibles mediante lista vacía.
- Ríos libres con superficie variable y dirección automática de cota alta a baja.
- Profundidad del fondo comprobada contra el nivel superficial por celda.
- Recorte estricto: fuera de `ancho / 2 + orilla` no cambia el terreno.
- Cruces viales comprobados en los modos proteger, vado y cortar.
- El vado conserva material vial y transitabilidad bajo un bloque de agua.
- La salida de agua alcanza el límite, abre el corredor montañoso y se exporta como zona válida.
- Tooltips definidos para todos los controles y acciones de la nueva herramienta.
- Vista 3D, voxel y schematic usan `water_surface` por celda.

## Regla de aislamiento

Una masa solo modifica su máscara y la orilla configurada. Un río solo modifica su cauce central y su orilla. Las carreteras normales, rampas, mesetas y cordillera no reciben ajustes de agua fuera de esos límites explícitos.

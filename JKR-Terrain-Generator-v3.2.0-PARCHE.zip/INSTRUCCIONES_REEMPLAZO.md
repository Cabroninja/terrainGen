# Instalación de JKR Terrain Generator v3.2.0

## Parche sobre v3.1.0

Coloca `JKR-Terrain-Generator-v3.2.0-PARCHE.zip` en la raíz del proyecto y ejecuta:

```bash
unzip -o JKR-Terrain-Generator-v3.2.0-PARCHE.zip
rm JKR-Terrain-Generator-v3.2.0-PARCHE.zip
docker compose down
docker compose up -d --build
docker compose logs --tail=100
```

Después realiza una recarga forzada del navegador (`Ctrl+F5`).

Los proyectos anteriores siguen abriendo normalmente. La máscara de agua antigua se interpreta como **Masa de agua** con valores predeterminados de profundidad 3, orilla Natural y caminos protegidos.

## Proyecto completo

Extrae `JKR-Terrain-Generator-v3.2.0-COMPLETO.zip` en una carpeta nueva y ejecuta `docker compose up -d --build`.

## Crear un río libre

1. Selecciona la capa **Agua**.
2. En **Herramienta de agua**, elige **Río libre**.
3. Ajusta ancho, profundidad, orilla y perfil.
4. Mantén clic y dibuja el recorrido libremente; al soltar se crea el objeto.
5. Activa **Final como salida entre montañas** antes de dibujar cuando el último tramo deba continuar fuera del mapa.
6. Usa la lista para seleccionar, editar o eliminar el río.
7. Compila y revisa el nivel escalonado en **Vista Minecraft**.

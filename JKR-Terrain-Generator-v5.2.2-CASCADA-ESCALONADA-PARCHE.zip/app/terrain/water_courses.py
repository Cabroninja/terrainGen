from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.ndimage import binary_dilation, distance_transform_edt

from app.core.models import ProjectConfig, WaterCourse


@dataclass(slots=True)
class WaterSystemResult:
    height: np.ndarray
    water_mask: np.ndarray
    water_surface: np.ndarray
    fall_mask: np.ndarray
    exit_mask: np.ndarray
    shore_mask: np.ndarray
    ford_mask: np.ndarray
    road_cut_mask: np.ndarray
    issues: list[dict]
    summaries: list[dict]


def _smoothstep(value: np.ndarray) -> np.ndarray:
    value = np.clip(value, 0.0, 1.0)
    return value * value * (3.0 - 2.0 * value)


def _smootherstep(value: np.ndarray) -> np.ndarray:
    value = np.clip(value, 0.0, 1.0)
    return value * value * value * (value * (value * 6.0 - 15.0) + 10.0)


def _shore_influence(normalized: np.ndarray, profile: str) -> np.ndarray:
    normalized = np.clip(normalized, 0.0, 1.0)
    if profile == "compact":
        phase = normalized
    elif profile == "smooth":
        phase = _smootherstep(normalized)
    else:
        phase = _smoothstep(normalized)
    return (1.0 - phase).astype(np.float32)


def _sample_height(height: np.ndarray, x: float, z: float) -> float:
    xi = int(np.clip(round(x), 0, height.shape[1] - 1))
    zi = int(np.clip(round(z), 0, height.shape[0] - 1))
    return float(height[zi, xi])


def _moving_average(values: np.ndarray, amount: int) -> np.ndarray:
    if values.size < 3 or amount <= 0:
        return values.astype(np.float32, copy=True)
    passes = max(1, int(round(amount / 25)))
    result = values.astype(np.float32, copy=True)
    first = float(result[0])
    last = float(result[-1])
    for _ in range(passes):
        padded = np.pad(result, (1, 1), mode="edge")
        result = (padded[:-2] + padded[1:-1] * 2.0 + padded[2:]) / 4.0
        result[0] = first
        result[-1] = last
    return result


def _nearest_boundary_point(point: np.ndarray, direction: np.ndarray, width: int, length: int) -> np.ndarray:
    x, z = float(point[0]), float(point[1])
    vx, vz = float(direction[0]), float(direction[1])
    candidates: list[tuple[float, float, float]] = []
    if abs(vx) > 1e-6:
        for edge_x in (0.0, float(width - 1)):
            t = (edge_x - x) / vx
            edge_z = z + t * vz
            if t > 0 and -1e-6 <= edge_z <= length - 1 + 1e-6:
                candidates.append((t, edge_x, float(np.clip(edge_z, 0, length - 1))))
    if abs(vz) > 1e-6:
        for edge_z in (0.0, float(length - 1)):
            t = (edge_z - z) / vz
            edge_x = x + t * vx
            if t > 0 and -1e-6 <= edge_x <= width - 1 + 1e-6:
                candidates.append((t, float(np.clip(edge_x, 0, width - 1)), edge_z))
    if candidates:
        _, bx, bz = min(candidates, key=lambda item: item[0])
        return np.asarray([bx, bz], dtype=np.float32)

    edge_candidates = [
        np.asarray([0.0, z], dtype=np.float32),
        np.asarray([float(width - 1), z], dtype=np.float32),
        np.asarray([x, 0.0], dtype=np.float32),
        np.asarray([x, float(length - 1)], dtype=np.float32),
    ]
    return min(edge_candidates, key=lambda candidate: float(np.sum((candidate - point) ** 2)))


def _prepare_course_points(
    course: WaterCourse,
    profile_height: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, float, bool, list[dict]]:
    issues: list[dict] = []
    points = np.asarray([(point.x, point.z) for point in course.points], dtype=np.float32)
    if points.shape[0] < 2:
        return points, np.zeros(0, dtype=np.float32), np.zeros(0, dtype=np.float32), 0.0, False, issues

    vectors = points[1:] - points[:-1]
    segment_lengths = np.sqrt(np.sum(vectors * vectors, axis=1))
    useful = np.concatenate(([True], segment_lengths > 0.25))
    points = points[useful]
    if points.shape[0] < 2:
        return points, np.zeros(0, dtype=np.float32), np.zeros(0, dtype=np.float32), 0.0, False, issues

    sampled = np.asarray([_sample_height(profile_height, x, z) for x, z in points], dtype=np.float32)
    reversed_flow = False
    if not course.exit_enabled and sampled[0] < sampled[-1]:
        points = points[::-1].copy()
        sampled = sampled[::-1].copy()
        reversed_flow = True

    user_points_count = points.shape[0]
    user_vectors = points[1:] - points[:-1]
    user_lengths = np.sqrt(np.sum(user_vectors * user_vectors, axis=1))
    user_total_length = float(user_lengths.sum())

    if course.exit_enabled:
        direction = points[-1] - points[-2]
        if float(np.linalg.norm(direction)) <= 1e-6:
            direction = np.asarray([1.0, 0.0], dtype=np.float32)
        boundary = _nearest_boundary_point(points[-1], direction, profile_height.shape[1], profile_height.shape[0])
        if float(np.linalg.norm(boundary - points[-1])) > 0.5:
            points = np.vstack([points, boundary])
            sampled = np.append(sampled, sampled[-1])
        if sampled[0] + 0.5 < sampled[min(user_points_count - 1, sampled.size - 1)]:
            issues.append({
                "severity": "warning",
                "code": "water_exit_uphill",
                "message": f"El río «{course.label or course.id}» llega a su salida desde una cota más baja; el cauce se excavará para conservar flujo descendente.",
            })

    vectors = points[1:] - points[:-1]
    segment_lengths = np.sqrt(np.sum(vectors * vectors, axis=1))
    cumulative = np.concatenate(([0.0], np.cumsum(segment_lengths))).astype(np.float32)
    smoothed = _moving_average(sampled, course.smoothing)

    # Modos del cauce:
    # - downhill: conserva el comportamiento clásico de flujo descendente y puede
    #   excavar elevaciones intermedias para no subir en la dirección del agua.
    # - follow: sigue el relieve local para evitar el efecto "bulldozer" sobre
    #   mesetas, terrazas y rampas intermedias.
    if course.relief_mode == 'follow':
        surface_profile = smoothed.astype(np.float32)
    else:
        surface_profile = np.minimum.accumulate(smoothed).astype(np.float32)
    if course.exit_enabled and surface_profile.size > user_points_count:
        surface_profile[user_points_count:] = surface_profile[user_points_count - 1]

    return points, cumulative, surface_profile, user_total_length, reversed_flow, issues


def _polyline_fields(points: np.ndarray, cumulative: np.ndarray, x: np.ndarray, z: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    best_distance_sq = np.full(x.shape, np.inf, dtype=np.float32)
    best_progress = np.zeros(x.shape, dtype=np.float32)
    for index, ((ax, az), (bx, bz)) in enumerate(zip(points[:-1], points[1:], strict=True)):
        vx = float(bx - ax)
        vz = float(bz - az)
        denominator = vx * vx + vz * vz
        if denominator <= 1e-8:
            continue
        t = np.clip(((x - ax) * vx + (z - az) * vz) / denominator, 0.0, 1.0)
        nearest_x = ax + t * vx
        nearest_z = az + t * vz
        distance_sq = (x - nearest_x) ** 2 + (z - nearest_z) ** 2
        closer = distance_sq < best_distance_sq
        best_distance_sq = np.where(closer, distance_sq, best_distance_sq)
        segment_length = float(cumulative[index + 1] - cumulative[index])
        best_progress = np.where(closer, cumulative[index] + t * segment_length, best_progress)
    return np.sqrt(best_distance_sq), best_progress



def _cascade_runs(cumulative: np.ndarray, surface_profile: np.ndarray, threshold: int) -> list[tuple[int, int, float]]:
    """Return merged sharp or sustained downward runs.

    Minecraft terrain often represents a cliff as many one-block steps. The
    previous detector only recognized a waterfall when one individual sample
    dropped by the complete threshold, so a long 1-block staircase escaped the
    cascade pass and became a triangular sheet of source water. This detector
    also recognizes a *cumulative* steep descent while ignoring normal gentle
    river gradients.
    """
    runs: list[tuple[int, int, float]] = []
    segment_count = surface_profile.size - 1
    index = 0
    minimum_step = 0.15
    maximum_flat_distance = 2.25
    minimum_average_slope = 0.60

    while index < segment_count:
        first_drop = float(surface_profile[index] - surface_profile[index + 1])
        if first_drop <= minimum_step:
            index += 1
            continue

        start = index
        cursor = index
        total_drop = 0.0
        flat_distance = 0.0
        maximum_single_drop = 0.0
        selected_end: int | None = None
        selected_drop = 0.0

        while cursor < segment_count:
            drop = float(surface_profile[cursor] - surface_profile[cursor + 1])
            segment_length = max(1e-4, float(cumulative[cursor + 1] - cumulative[cursor]))

            # A meaningful uphill step closes the candidate. Tiny sampling
            # oscillations are tolerated so freehand smoothing does not split a
            # single cliff into many cascades.
            if drop < -0.5:
                break

            if drop > minimum_step:
                total_drop += drop
                maximum_single_drop = max(maximum_single_drop, drop)
                flat_distance = 0.0
            else:
                flat_distance += segment_length
                if flat_distance > maximum_flat_distance:
                    break

            horizontal_length = max(1e-4, float(cumulative[cursor + 1] - cumulative[start]))
            average_slope = total_drop / horizontal_length
            abrupt = maximum_single_drop >= float(threshold)
            sustained = total_drop >= float(threshold) and average_slope >= minimum_average_slope
            if abrupt or sustained:
                selected_end = cursor
                selected_drop = total_drop

            cursor += 1

        if selected_end is not None:
            runs.append((start, selected_end, selected_drop))
            index = selected_end + 1
        else:
            index = start + 1

    # Merge events separated only by a very short ledge. A terraced cliff can
    # contain one or two flat blocks between descending sections and should
    # still become one waterfall with one plunge pool.
    merged: list[tuple[int, int, float]] = []
    for run in runs:
        if not merged:
            merged.append(run)
            continue
        previous_start, previous_end, previous_drop = merged[-1]
        gap = float(cumulative[run[0]] - cumulative[previous_end + 1])
        if gap <= maximum_flat_distance:
            merged[-1] = (previous_start, run[1], previous_drop + run[2])
        else:
            merged.append(run)
    return merged


def _apply_follow_cascades(
    *,
    course: WaterCourse,
    points: np.ndarray,
    cumulative: np.ndarray,
    surface_profile: np.ndarray,
    progress: np.ndarray,
    distance: np.ndarray,
    gx: np.ndarray,
    gz: np.ndarray,
    x0: int,
    z0: int,
    half_width: float,
    terrain_slice: np.ndarray,
    before: np.ndarray,
    road_slice: np.ndarray,
    local_mask: np.ndarray,
    local_surface: np.ndarray,
    local_fall: np.ndarray,
    local_shore: np.ndarray,
    local_cut: np.ndarray,
    issues: list[dict],
    map_width: int,
    map_length: int,
) -> dict:
    """Add localized, Minecraft-safe waterfalls for follow-relief rivers.

    A sharp descending run is rebuilt as three explicit parts:
    1. a narrow vertical curtain at the upper lip;
    2. a low, constant-level connector through the former sloped run;
    3. a rounded plunge pool directly under and after the curtain.

    Keeping the high water surface only on the narrow curtain prevents the
    triangular wedge of falling water that appeared when the complete sloped
    run was filled up to the upper level.
    """
    if course.relief_mode != "follow" or not course.cascade_containment:
        return {"detected": 0, "contained": 0, "cells": 0, "pool_cells": 0}

    runs = _cascade_runs(cumulative, surface_profile, course.cascade_threshold)
    contained = 0
    cascade_cells = 0
    pool_cells = 0

    for run_number, (start, end, drop) in enumerate(runs, start=1):
        high_surface = float(surface_profile[start])
        low_surface = float(surface_profile[end + 1])
        start_progress = float(cumulative[start])
        end_progress = float(cumulative[end + 1])
        event_length = max(0.5, end_progress - start_progress)
        progress_padding = max(0.5, min(1.5, float(course.width) * 0.15))

        # Direction from the upper lip toward the lower river. Using the complete
        # run direction is more stable than a single short segment on curved
        # freehand paths.
        upper_point = points[start]
        lower_point = points[end + 1]
        direction = lower_point - upper_point
        norm = float(np.linalg.norm(direction))
        if norm <= 1e-6:
            direction = points[min(start + 1, points.shape[0] - 1)] - points[start]
            norm = float(np.linalg.norm(direction))
        if norm <= 1e-6:
            direction = np.asarray([1.0, 0.0], dtype=np.float32)
        else:
            direction = direction / norm

        # The normal follow-relief pass has already produced source-water cells
        # on every step of the descending slope. Rebuild that central run at the
        # lower level so it becomes a narrow receiving channel instead of a high
        # triangular volume of water.
        run_geometry = (
            (progress >= start_progress - 0.25)
            & (progress <= end_progress + progress_padding)
            & (distance <= half_width + 1e-6)
        )
        blocked_roads = run_geometry & road_slice & (course.road_policy != "cut")
        lower_channel = run_geometry & ~blocked_roads
        if not np.any(lower_channel):
            issues.append({
                "severity": "warning",
                "code": "water_cascade_blocked",
                "message": f"La cascada {run_number} de «{course.label or course.id}» quedó bloqueada por un camino protegido.",
            })
            continue

        low_floor = low_surface - float(course.depth) - 1.0
        terrain_slice[lower_channel] = np.minimum(before[lower_channel], low_floor)
        local_mask[lower_channel] = 1
        local_surface[lower_channel] = int(round(low_surface))
        local_fall[lower_channel] = 0
        if course.road_policy == "cut":
            local_cut[lower_channel & road_slice] = 1

        # A waterfall must be a short curtain, never the entire horizontal run.
        # Its length stays compact even when the sampled terrain descends over
        # many blocks.
        curtain_length = max(0.75, min(1.75, float(course.width) * 0.18))
        curtain = (
            (progress >= start_progress - 0.35)
            & (progress <= start_progress + curtain_length)
            & (distance <= half_width + 1e-6)
            & ~blocked_roads
        )
        if not np.any(curtain):
            curtain = lower_channel & (progress <= start_progress + max(1.0, curtain_length))

        terrain_slice[curtain] = np.minimum(terrain_slice[curtain], low_floor)
        local_mask[curtain] = 1
        local_surface[curtain] = int(round(high_surface))
        local_fall[curtain] = 1

        # Rounded plunge pool directly after the lip. It overlaps the low
        # connector, so the falling column lands in water instead of spreading
        # across the exposed slope. The pool length grows moderately with the
        # original run but remains compact.
        pool_half_length = max(2.5, min(9.0, half_width * 0.75 + drop * 0.12 + 1.5))
        pool_half_width = half_width + max(1.0, min(3.0, float(course.shore_width) * 0.35))
        # The impact basin belongs at the *lower end* of the descending run.
        # Centering it from the upper lip placed it halfway up long terraced
        # cliffs and left the real foot without a receiving pool.
        downstream_offset = min(2.0, max(0.75, half_width * 0.28))
        center_x = float(lower_point[0] + direction[0] * downstream_offset)
        center_z = float(lower_point[1] + direction[1] * downstream_offset)
        dx = gx - center_x
        dz = gz - center_z
        longitudinal = dx * float(direction[0]) + dz * float(direction[1])
        lateral = -dx * float(direction[1]) + dz * float(direction[0])
        pool = (
            (longitudinal / (pool_half_length * 1.15)) ** 2
            + (lateral / pool_half_width) ** 2
            <= 1.0
        )
        # Keep the basin close to the waterfall and its connector instead of
        # allowing a large oval to reach unrelated terrain behind the lip.
        pool &= longitudinal >= -pool_half_length * 0.95
        pool &= longitudinal <= pool_half_length * 1.15
        if course.road_policy != "cut":
            pool &= ~road_slice
        new_pool = pool & (local_mask == 0)
        terrain_slice[pool] = np.minimum(terrain_slice[pool], low_floor)
        local_mask[pool] = 1
        # Assignment is intentional: the basin must stay at the lower level.
        # Re-applying the upper value here would recreate the triangular wedge.
        pool_without_curtain = pool & ~curtain
        local_surface[pool_without_curtain] = int(round(low_surface))
        local_fall[pool_without_curtain] = 0
        if course.road_policy == "cut":
            local_cut[pool & road_slice] = 1

        # Local rock throat around the actual vertical curtain only. The former
        # implementation extended this wall over the complete descending run.
        wall_width = max(1.0, min(2.25, 0.75 + float(course.shore_width) * 0.20))
        curtain_zone = (
            (progress >= start_progress - 0.5)
            & (progress <= start_progress + curtain_length + 0.5)
        )
        side_walls = (
            curtain_zone
            & (distance > half_width)
            & (distance <= half_width + wall_width)
            & ~pool
            & ~road_slice
        )
        terrain_slice[side_walls] = np.maximum(terrain_slice[side_walls], high_surface)
        local_shore[side_walls] = 1

        # One-cell rim around the lower pool. Only deficient cells are raised,
        # preserving naturally higher terrain and avoiding a visible wall.
        pool_ring = binary_dilation(pool, iterations=1) & ~pool & ~curtain & (local_mask == 0) & ~road_slice
        terrain_slice[pool_ring] = np.maximum(terrain_slice[pool_ring], low_surface)
        local_shore[pool_ring] = 1

        global_z, global_x = np.where(curtain)
        touches_border = bool(np.any(
            (global_x + x0 == 0)
            | (global_x + x0 == map_width - 1)
            | (global_z + z0 == 0)
            | (global_z + z0 == map_length - 1)
        ))
        road_gap = bool(np.any(blocked_roads))
        if touches_border and not course.exit_enabled:
            issues.append({
                "severity": "warning",
                "code": "water_cascade_border",
                "message": f"La cascada {run_number} de «{course.label or course.id}» toca el borde del mapa sin ser una salida autorizada.",
            })
        if road_gap:
            issues.append({
                "severity": "warning",
                "code": "water_cascade_road_gap",
                "message": f"La cascada {run_number} de «{course.label or course.id}» cruza un camino protegido; revisa la contención en ese punto.",
            })
        if not touches_border and not road_gap:
            contained += 1

        cascade_cells += int(curtain.sum())
        pool_cells += int(new_pool.sum())

    return {
        "detected": len(runs),
        "contained": contained,
        "cells": cascade_cells,
        "pool_cells": pool_cells,
    }

def _apply_mass_water(
    height: np.ndarray,
    water_mask: np.ndarray,
    water_surface: np.ndarray,
    painted_water: np.ndarray,
    roads: np.ndarray,
    config: ProjectConfig,
    shore_mask: np.ndarray,
    ford_mask: np.ndarray,
    road_cut_mask: np.ndarray,
) -> dict:
    painted = painted_water.astype(bool, copy=False)
    if not np.any(painted):
        return {"cells": 0, "road_cells": 0}

    protected = (roads > 0) if config.water_road_policy == "protect" else np.zeros_like(painted)
    active = painted & ~protected
    floor_y = float(config.sea_level - config.water_depth)
    original = height.copy()
    normal_channel = active & ~((roads > 0) & (config.water_road_policy == "ford"))
    height[normal_channel] = np.minimum(height[normal_channel], floor_y)

    ford = active & (roads > 0) & (config.water_road_policy == "ford")
    cut = active & (roads > 0) & (config.water_road_policy == "cut")
    ford_mask[ford] = 1
    road_cut_mask[cut] = 1
    surface_values = np.full(height.shape, config.sea_level, dtype=np.int16)
    if np.any(ford):
        surface_values[ford] = np.rint(original[ford] + 1.0).astype(np.int16)

    water_mask[active] = 1
    water_surface[active] = np.maximum(water_surface[active], surface_values[active])

    if config.shore_width > 0 and np.any(active):
        distance = distance_transform_edt(~active)
        shore = (distance > 0) & (distance <= float(config.shore_width)) & ~protected
        if np.any(shore):
            influence = _shore_influence(distance / float(config.shore_width), config.water_shore_profile)
            target = np.minimum(original, float(config.sea_level - 1))
            shore_mask[shore] = 1
            height[shore] = np.minimum(
                height[shore],
                original[shore] * (1.0 - influence[shore]) + target[shore] * influence[shore],
            )

    return {"cells": int(active.sum()), "road_cells": int((active & (roads > 0)).sum())}


def apply_water_system(
    source_height: np.ndarray,
    profile_height: np.ndarray,
    painted_water: np.ndarray,
    roads: np.ndarray,
    courses: list[WaterCourse],
    config: ProjectConfig,
) -> WaterSystemResult:
    """Compile painted lakes and freehand river objects with per-cell levels.

    Painted water remains a simple mass at the configured global level. Rivers
    are explicit freehand objects: their centerline follows the terrain/ramp
    profile from high to low, their channel and shore are strictly bounded, and
    an optional outlet extends the last stroke toward the map boundary so the
    water can disappear through the mountain ring.
    """

    height = source_height.astype(np.float32, copy=True)
    water_mask = np.zeros(height.shape, dtype=np.uint8)
    water_surface = np.full(height.shape, -1, dtype=np.int16)
    fall_mask = np.zeros(height.shape, dtype=np.uint8)
    exit_mask = np.zeros(height.shape, dtype=np.uint8)
    shore_mask = np.zeros(height.shape, dtype=np.uint8)
    ford_mask = np.zeros(height.shape, dtype=np.uint8)
    road_cut_mask = np.zeros(height.shape, dtype=np.uint8)
    issues: list[dict] = []
    summaries: list[dict] = []

    mass_summary = _apply_mass_water(height, water_mask, water_surface, painted_water, roads, config, shore_mask, ford_mask, road_cut_mask)

    map_length, map_width = height.shape
    for course in courses:
        points, cumulative, surface_profile, user_total_length, reversed_flow, course_issues = _prepare_course_points(course, profile_height)
        issues.extend(course_issues)
        if points.shape[0] < 2 or cumulative.size < 2 or float(cumulative[-1]) <= 1e-6:
            issues.append({
                "severity": "error",
                "code": "water_course_zero_length",
                "message": f"El río «{course.label or course.id}» no tiene un recorrido útil.",
            })
            continue

        half_width = float(course.width) / 2.0
        outer_radius = half_width + float(course.shore_width)
        x0 = max(0, int(np.floor(points[:, 0].min() - outer_radius - 1)))
        x1 = min(map_width - 1, int(np.ceil(points[:, 0].max() + outer_radius + 1)))
        z0 = max(0, int(np.floor(points[:, 1].min() - outer_radius - 1)))
        z1 = min(map_length - 1, int(np.ceil(points[:, 1].max() + outer_radius + 1)))
        zz, xx = np.mgrid[z0:z1 + 1, x0:x1 + 1]
        gx = xx.astype(np.float32)
        gz = zz.astype(np.float32)
        distance, progress = _polyline_fields(points, cumulative, gx, gz)
        surface = np.interp(progress, cumulative, surface_profile).astype(np.float32)
        center = distance <= half_width + 1e-6
        road_slice = roads[z0:z1 + 1, x0:x1 + 1] > 0
        protected = road_slice if course.road_policy == "protect" else np.zeros_like(center)
        active_center = center & ~protected

        terrain_slice = height[z0:z1 + 1, x0:x1 + 1]
        before = terrain_slice.copy()
        floor = surface - float(course.depth)
        ford = active_center & road_slice & (course.road_policy == "ford")
        cut = active_center & road_slice & (course.road_policy == "cut")
        normal = active_center & ~ford
        terrain_slice[normal] = np.minimum(terrain_slice[normal], floor[normal])

        surface_i = np.rint(surface).astype(np.int16)
        if np.any(ford):
            surface_i[ford] = np.rint(before[ford] + 1.0).astype(np.int16)

        local_ford = ford_mask[z0:z1 + 1, x0:x1 + 1]
        local_cut = road_cut_mask[z0:z1 + 1, x0:x1 + 1]
        local_ford[ford] = 1
        local_cut[cut] = 1

        local_mask = water_mask[z0:z1 + 1, x0:x1 + 1]
        local_surface = water_surface[z0:z1 + 1, x0:x1 + 1]
        local_mask[active_center] = 1
        local_surface[active_center] = np.maximum(local_surface[active_center], surface_i[active_center])

        if course.shore_width > 0:
            lateral = np.maximum(distance - half_width, 0.0)
            shore = (
                (lateral > 0)
                & (lateral <= float(course.shore_width) + 1e-6)
                & ~protected
            )
            if np.any(shore):
                influence = _shore_influence(lateral / float(course.shore_width), course.shore_profile)
                bank_target = np.minimum(before, surface - 1.0)
                local_shore = shore_mask[z0:z1 + 1, x0:x1 + 1]
                local_shore[shore] = 1
                terrain_slice[shore] = np.minimum(
                    terrain_slice[shore],
                    before[shore] * (1.0 - influence[shore]) + bank_target[shore] * influence[shore],
                )

        local_fall = fall_mask[z0:z1 + 1, x0:x1 + 1]
        cascade_summary = _apply_follow_cascades(
            course=course,
            points=points,
            cumulative=cumulative,
            surface_profile=surface_profile,
            progress=progress,
            distance=distance,
            gx=gx,
            gz=gz,
            x0=x0,
            z0=z0,
            half_width=half_width,
            terrain_slice=terrain_slice,
            before=before,
            road_slice=road_slice,
            local_mask=local_mask,
            local_surface=local_surface,
            local_fall=local_fall,
            local_shore=shore_mask[z0:z1 + 1, x0:x1 + 1],
            local_cut=local_cut,
            issues=issues,
            map_width=map_width,
            map_length=map_length,
        )

        if course.exit_enabled:
            local_exit = exit_mask[z0:z1 + 1, x0:x1 + 1]
            local_exit[active_center & (progress >= user_total_length - 1e-3)] = 1

        road_cells = int((active_center & road_slice).sum())
        summaries.append({
            "id": course.id,
            "label": course.label,
            "length": round(float(cumulative[-1]), 3),
            "width": course.width,
            "depth": course.depth,
            "shore_width": course.shore_width,
            "shore_profile": course.shore_profile,
            "road_policy": course.road_policy,
            "relief_mode": course.relief_mode,
            "cascade_containment": course.cascade_containment,
            "cascade_threshold": course.cascade_threshold,
            "cascades_detected": cascade_summary["detected"],
            "cascades_contained": cascade_summary["contained"],
            "cascade_cells": cascade_summary["cells"],
            "plunge_pool_cells": cascade_summary["pool_cells"],
            "smoothing": course.smoothing,
            "exit_enabled": course.exit_enabled,
            "flow_reversed": reversed_flow,
            "start_surface": round(float(surface_profile[0]), 3),
            "end_surface": round(float(surface_profile[-1]), 3),
            "water_cells": int(active_center.sum()) + int(cascade_summary["pool_cells"]),
            "road_cells": road_cells,
        })

    return WaterSystemResult(
        height=height,
        water_mask=water_mask,
        water_surface=water_surface,
        fall_mask=fall_mask,
        exit_mask=exit_mask,
        shore_mask=shore_mask,
        ford_mask=ford_mask,
        road_cut_mask=road_cut_mask,
        issues=issues,
        summaries=summaries,
    )

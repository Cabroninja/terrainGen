# Validación de la entrega v3.1.0

## Comandos ejecutados

```bash
python -m compileall -q app scripts tests
node --check app/static/app.js
node --check app/static/road-ramp-tool.js
node --check app/static/config-help.js
node --check app/static/voxel-viewer.js
pytest -q
```

## Resultado

- 50 pruebas automáticas aprobadas.
- API de salud actualizada a v3.1.0.
- Compatibilidad con proyectos sin `road_ramps` y rampas v3.0.0 sin campos de suavizado.
- Rampa central monotónica y sin saltos superiores a un bloque al cuantizar.
- Suavizado lateral adaptativo limitado estrictamente por `max_side_width`.
- Suavizado desactivado conserva la transición fija anterior.
- Tooltips definidos para todos los controles y acciones de rampa.
- Manifiesto voxel expone distancia máxima de 16 chunks.

## Regla de aislamiento

Fuera de `ancho transitable / 2 + anchura lateral efectiva`, una rampa no modifica ninguna celda. La anchura efectiva nunca supera **Anchura lateral máxima**.

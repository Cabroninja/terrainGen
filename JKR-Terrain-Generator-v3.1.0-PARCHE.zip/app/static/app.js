import { initializeHelp } from './config-help.js';
import { Terrain3DViewer } from './terrain-viewer.js';
import { VoxelTerrainViewer } from './voxel-viewer.js';
import { normalizeElevationProfile, elevationProfileInfluence } from './brush-profile.js';
import { normalizePlateauSettings, plateauInfluence, heightToLayerValue, layerValueToHeight } from './plateau-tool.js';
import { normalizeRoadRampSettings, analyzeRoadRamp } from './road-ramp-tool.js';

const $ = (id) => document.getElementById(id);
function readPreference(key, fallback = null) { try { return localStorage.getItem(key) ?? fallback; } catch (_) { return fallback; } }
function writePreference(key, value) { try { localStorage.setItem(key, value); } catch (_) { /* Preferencia no persistente en este contexto. */ } }
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const MIN_MAP_SIZE = 32;
const MAX_MAP_SIZE = 2048;
const MAX_EXPORT_VOXELS = 750000000;
const EXPORT_WARNING_VOXELS = 250000000;

function createMarkerId() {
  try {
    if (globalThis.crypto && typeof globalThis.crypto.randomUUID === 'function') return globalThis.crypto.randomUUID();
    if (globalThis.crypto && typeof globalThis.crypto.getRandomValues === 'function') {
      const bytes = new Uint8Array(16); globalThis.crypto.getRandomValues(bytes);
      bytes[6] = (bytes[6] & 0x0f) | 0x40; bytes[8] = (bytes[8] & 0x3f) | 0x80;
      const hex = Array.from(bytes, (value) => value.toString(16).padStart(2, '0')).join('');
      return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
    }
  } catch (_) { /* Continúa con el fallback compatible con HTTP. */ }
  return `marker-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
}

function createRoadRampId() {
  return `ramp-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

const LAYERS = {
  playable: { label: 'Límite jugable', color: '#d7e1dc', default: 255, kind: 'mask', help: 'layer_playable' },
  regions: { label: 'Regiones', color: '#85c0d3', default: 1, kind: 'category', help: 'layer_regions' },
  roads: { label: 'Caminos', color: '#d6aa6b', default: 0, kind: 'roads', help: 'layer_roads' },
  height_base: { label: 'Altura base', color: '#a7c7a3', default: 128, kind: 'plateau', help: 'layer_height_base' },
  height_modifier: { label: 'Modificador de altura', color: '#d2a8d8', default: 128, kind: 'modifier', help: 'layer_height_modifier' },
  water: { label: 'Agua', color: '#4d89c8', default: 0, kind: 'mask', help: 'layer_water' },
  reserved: { label: 'Zonas reservadas', color: '#d184d5', default: 0, kind: 'mask', help: 'layer_reserved' },
  materials: { label: 'Materiales', color: '#9cba76', default: 0, kind: 'material', help: 'layer_materials' },
  exclusion: { label: 'Exclusión decoración', color: '#cf6f6f', default: 0, kind: 'mask', help: 'layer_exclusion' },
};

const REGION_COLORS = [
  [0, 0, 0], [85, 142, 102], [93, 119, 171], [165, 111, 78], [128, 93, 157],
  [178, 155, 74], [69, 147, 151], [161, 86, 102], [103, 126, 77], [87, 103, 138],
  [146, 112, 65], [119, 82, 128], [67, 123, 112], [143, 78, 86], [115, 130, 156], [149, 139, 91],
];

const MATERIAL_OPTIONS = [
  ['0', 'Automático'], ['1', 'Césped'], ['2', 'Tierra'], ['3', 'Piedra'], ['4', 'Arena'], ['5', 'Nieve'], ['6', 'Grava'], ['7', 'Agua'],
];

const ACTIONS = {
  mask: [['add', 'Añadir'], ['erase', 'Borrar'], ['fill', 'Rellenar área']],
  category: [['paint', 'Pintar región'], ['erase', 'Borrar a 0'], ['fill', 'Rellenar área']],
  roads: [['primary', 'Camino principal'], ['secondary', 'Camino secundario'], ['erase', 'Borrar camino']],
  plateau: [['paint', 'Pintar meseta'], ['restore', 'Restaurar altura media']],
  modifier: [['raise', 'Elevar'], ['lower', 'Bajar'], ['reset', 'Volver a cero'], ['smooth', 'Suavizar']],
  material: [['paint', 'Pintar material'], ['erase', 'Volver a automático'], ['fill', 'Rellenar área']],
};

const PRESET_GROUPS = {
  brush: {
    label: 'pincel', storageKey: 'jkr-terrain-presets-brush-v1',
    fields: [['plateau-height', 'value'], ['plateau-radius', 'value'], ['plateau-slope-width', 'value'], ['plateau-support-enabled', 'checked'], ['plateau-support-width', 'value'], ['plateau-support-height', 'value'], ['plateau-action', 'value'], ['road-tool-mode', 'value'], ['road-ramp-type', 'value'], ['road-ramp-width', 'value'], ['road-ramp-shoulder', 'value'], ['road-ramp-ratio', 'value'], ['road-ramp-start-landing', 'value'], ['road-ramp-end-landing', 'value'], ['road-ramp-smooth-sides', 'checked'], ['road-ramp-side-ratio', 'value'], ['road-ramp-max-side-width', 'value'], ['road-ramp-side-roundness', 'value'], ['road-ramp-follow-terrain', 'checked'], ['brush-size', 'value'], ['brush-core-mode', 'checked'], ['brush-core-radius', 'value'], ['brush-hardness', 'value'], ['elevation-profile-enabled', 'checked'], ['brush-slope-width', 'value'], ['brush-base-enabled', 'checked'], ['brush-base-width', 'value'], ['brush-base-intensity', 'value'], ['brush-profile-shape', 'value'], ['brush-terrace-steps', 'value'], ['brush-strict-clip', 'checked'], ['brush-opacity', 'value'], ['brush-strength', 'value'], ['brush-shape', 'value'], ['stroke-mode', 'value'], ['stroke-accumulation', 'checked']],
  },
  compilation: {
    label: 'compilación', storageKey: 'jkr-terrain-presets-compilation-v1',
    fields: [['modifier-range', 'value'], ['shore-width', 'value'], ['max-walk-slope', 'value'], ['surface-depth', 'value'], ['data-version', 'value']],
  },
  mountain: {
    label: 'borde montañoso', storageKey: 'jkr-terrain-presets-mountain-v1',
    fields: [['mountain-border-enabled', 'checked'], ['mountain-outer-width', 'value'], ['mountain-inner-transition', 'value'], ['mountain-height', 'value'], ['mountain-irregularity', 'value'], ['mountain-roughness', 'value'], ['mountain-exit-width', 'value'], ['mountain-exit-transition', 'value'], ['mountain-canvas-guide', 'checked']],
  },
};

function encodeRle(array) {
  if (!array.length) return [];
  const output = []; let value = array[0]; let count = 1;
  for (let index = 1; index < array.length; index += 1) {
    if (array[index] === value) count += 1;
    else { output.push(value, count); value = array[index]; count = 1; }
  }
  output.push(value, count); return output;
}

function decodeRle(data, expected) {
  const output = new Uint8Array(expected); let offset = 0;
  if (!Array.isArray(data) || data.length % 2) throw new Error('Capa RLE inválida.');
  for (let index = 0; index < data.length; index += 2) {
    const value = Number(data[index]); const count = Number(data[index + 1]);
    if (!Number.isInteger(value) || value < 0 || value > 255 || !Number.isInteger(count) || count <= 0 || offset + count > expected) throw new Error('Capa RLE inválida.');
    output.fill(value, offset, offset + count); offset += count;
  }
  if (offset !== expected) throw new Error('La capa no coincide con las dimensiones.');
  return output;
}

function downloadJson(filename, data) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob); const anchor = document.createElement('a'); anchor.href = url; anchor.download = filename; anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

class TerrainEditor {
  constructor(help) {
    this.help = help;
    this.canvas = $('terrain-canvas'); this.overlay = $('overlay-canvas');
    this.ctx = this.canvas.getContext('2d', { alpha: false }); this.overlayCtx = this.overlay.getContext('2d');
    this.width = 256; this.length = 256; this.layers = {}; this.visibility = {}; this.locked = {};
    this.activeLayer = 'height_base'; this.undoStack = []; this.redoStack = []; this.maxHistory = 80;
    this.currentChanges = null; this.strokeBaseValues = null; this.strokeInfluence = null; this.pointerDown = false; this.lineStart = null; this.hover = null; this.renderQueued = false;
    this.markerTool = null; this.plateauPickHeight = false; this.markers = []; this.roadRamps = []; this.roadRampDraft = []; this.roadRampEditingId = null; this.selectedRoadRampId = null; this.playableBoundaryCache = null; this.playableBoundaryPathCache = null; this.dirty = true; this.compiledFiles = null; this.activePreview = 'preview';
    this.viewer3d = new Terrain3DViewer({
      canvas: $('terrain-3d-canvas'), status: $('terrain-3d-status'), scaleInput: $('terrain-3d-scale'), scaleValue: $('terrain-3d-scale-value'),
      wireframeInput: $('terrain-3d-wireframe'), resetButton: $('terrain-3d-reset'), expandButton: $('terrain-3d-expand'),
    });
    this.voxelViewer = new VoxelTerrainViewer({
      canvas: $('voxel-3d-canvas'), status: $('voxel-3d-status'), resetButton: $('voxel-3d-reset'), expandButton: $('voxel-3d-expand'),
      modeInput: $('voxel-3d-mode'), renderDistanceInput: $('voxel-render-distance'), renderDistanceValue: $('voxel-render-distance-value'),
      edgesInput: $('voxel-edges'), waterInput: $('voxel-water'), cutInput: $('voxel-cut-y'), cutValue: $('voxel-cut-y-value'),
    });
    $('stroke-accumulation').checked = readPreference('jkr-terrain-stroke-accumulation', 'false') === 'true';
    $('brush-core-mode').checked = readPreference('jkr-terrain-brush-core-mode', 'false') === 'true';
    $('brush-core-radius').value = readPreference('jkr-terrain-brush-core-radius', '6');
    $('elevation-profile-enabled').checked = readPreference('jkr-terrain-elevation-profile-enabled', 'false') === 'true';
    $('brush-base-enabled').checked = readPreference('jkr-terrain-brush-base-enabled', 'true') === 'true';
    $('brush-strict-clip').checked = readPreference('jkr-terrain-brush-strict-clip', 'true') === 'true';
    $('plateau-height').value = readPreference('jkr-terrain-plateau-height', '72');
    $('plateau-radius').value = readPreference('jkr-terrain-plateau-radius', '19');
    $('plateau-slope-width').value = readPreference('jkr-terrain-plateau-slope-width', '8');
    $('plateau-support-enabled').checked = readPreference('jkr-terrain-plateau-support-enabled', 'false') === 'true';
    $('plateau-support-width').value = readPreference('jkr-terrain-plateau-support-width', '24');
    $('plateau-support-height').value = readPreference('jkr-terrain-plateau-support-height', '25');
    $('road-ramp-width').value = readPreference('jkr-terrain-road-ramp-width', '7');
    $('road-ramp-shoulder').value = readPreference('jkr-terrain-road-ramp-shoulder', '5');
    $('road-ramp-ratio').value = readPreference('jkr-terrain-road-ramp-ratio', '3');
    $('road-ramp-start-landing').value = readPreference('jkr-terrain-road-ramp-start-landing', '4');
    $('road-ramp-end-landing').value = readPreference('jkr-terrain-road-ramp-end-landing', '5');
    $('road-ramp-smooth-sides').checked = readPreference('jkr-terrain-road-ramp-smooth-sides', 'true') === 'true';
    $('road-ramp-side-ratio').value = readPreference('jkr-terrain-road-ramp-side-ratio', '2');
    $('road-ramp-max-side-width').value = readPreference('jkr-terrain-road-ramp-max-side-width', '24');
    $('road-ramp-side-roundness').value = readPreference('jkr-terrain-road-ramp-side-roundness', '65');
    $('road-ramp-follow-terrain').checked = readPreference('jkr-terrain-road-ramp-follow-terrain', 'true') === 'true';
    this.initializeLayers(); this.buildLayerList(); this.bind(); this.initializePresetManagers(); this.updateLayerControls(); this.updateBrushProfileUi(); this.applyZoom(); this.render(); this.updateVoxelBudget(); this.updateMountainUi();
  }

  initializeLayers() {
    const size = this.width * this.length;
    for (const [name, meta] of Object.entries(LAYERS)) {
      this.layers[name] = new Uint8Array(size); this.layers[name].fill(meta.default);
      this.visibility[name] = true; this.locked[name] = false;
    }
  }

  buildLayerList() {
    const list = $('layer-list'); list.replaceChildren();
    for (const [name, meta] of Object.entries(LAYERS)) {
      const row = document.createElement('div'); row.className = `layer-row${name === this.activeLayer ? ' active' : ''}`; row.dataset.layer = name;
      const eye = document.createElement('button'); eye.textContent = this.visibility[name] ? '👁' : '—'; eye.title = 'Mostrar u ocultar capa';
      eye.addEventListener('click', (event) => { event.stopPropagation(); this.visibility[name] = !this.visibility[name]; eye.textContent = this.visibility[name] ? '👁' : '—'; this.render(); });
      const swatch = document.createElement('span'); swatch.className = 'layer-color'; swatch.style.background = meta.color;
      const label = document.createElement('span'); label.className = 'layer-name'; label.textContent = meta.label;
      const helpButton = document.createElement('button'); helpButton.className = 'help-button layer-help'; helpButton.textContent = '?'; this.help?.attach(helpButton, meta.help);
      const lock = document.createElement('button'); lock.className = 'lock'; lock.textContent = this.locked[name] ? '●' : '○'; lock.title = 'Bloquear capa';
      lock.addEventListener('click', (event) => { event.stopPropagation(); this.locked[name] = !this.locked[name]; lock.textContent = this.locked[name] ? '●' : '○'; });
      row.append(eye, swatch, label, helpButton, lock); row.addEventListener('click', () => this.setActiveLayer(name)); list.append(row);
    }
  }

  bind() {
    this.overlay.addEventListener('pointerdown', (event) => this.pointerStart(event));
    this.overlay.addEventListener('pointermove', (event) => this.pointerMove(event));
    this.overlay.addEventListener('pointerup', (event) => this.pointerEnd(event));
    this.overlay.addEventListener('pointercancel', (event) => this.pointerEnd(event));
    this.overlay.addEventListener('pointerleave', () => { if (!this.pointerDown) { this.hover = null; this.renderOverlay(); } });
    this.overlay.addEventListener('contextmenu', (event) => event.preventDefault());

    $('undo').addEventListener('click', () => this.undo()); $('redo').addEventListener('click', () => this.redo());
    $('clear-layer').addEventListener('click', () => this.clearLayer()); $('show-all').addEventListener('click', () => this.showAll());
    $('zoom').addEventListener('input', () => this.applyZoom()); $('grid-toggle').addEventListener('change', () => this.renderOverlay());
    $('view-mode').addEventListener('change', () => this.render());
    $('brush-action').addEventListener('change', () => this.updateValueOptions());
    $('dimension-preset').addEventListener('change', () => this.applyPreset()); $('apply-dimensions').addEventListener('click', () => this.resizeFromInputs());
    $('randomize-seed').addEventListener('click', () => this.randomizeSeed());
    $('stroke-accumulation').addEventListener('change', () => writePreference('jkr-terrain-stroke-accumulation', String($('stroke-accumulation').checked)));
    $('brush-core-mode').addEventListener('change', () => { writePreference('jkr-terrain-brush-core-mode', String($('brush-core-mode').checked)); this.updateBrushProfileUi(); this.renderOverlay(); });
    $('brush-core-radius').addEventListener('input', () => { writePreference('jkr-terrain-brush-core-radius', $('brush-core-radius').value); this.updateBrushProfileUi(); this.renderOverlay(); });
    $('brush-size').addEventListener('input', () => { this.updateBrushProfileUi(); this.renderOverlay(); });
    $('brush-hardness').addEventListener('input', () => { this.updateBrushProfileUi(); this.renderOverlay(); });
    $('elevation-profile-enabled').addEventListener('change', () => { writePreference('jkr-terrain-elevation-profile-enabled', String($('elevation-profile-enabled').checked)); this.updateBrushProfileUi(); this.renderOverlay(); });
    $('brush-base-enabled').addEventListener('change', () => { writePreference('jkr-terrain-brush-base-enabled', String($('brush-base-enabled').checked)); this.updateBrushProfileUi(); this.renderOverlay(); });
    $('brush-strict-clip').addEventListener('change', () => writePreference('jkr-terrain-brush-strict-clip', String($('brush-strict-clip').checked)));
    for (const id of ['plateau-height', 'plateau-radius', 'plateau-slope-width', 'plateau-support-width', 'plateau-support-height']) $(id).addEventListener('input', () => { writePreference(`jkr-terrain-${id}`, $(id).value); this.updatePlateauUi(); this.renderOverlay(); });
    $('plateau-support-enabled').addEventListener('change', () => { writePreference('jkr-terrain-plateau-support-enabled', String($('plateau-support-enabled').checked)); this.updatePlateauUi(); this.renderOverlay(); });
    $('plateau-action').addEventListener('change', () => { this.updatePlateauUi(); this.renderOverlay(); });
    $('plateau-pick-height').addEventListener('click', () => this.togglePlateauHeightPicker());
    $('road-tool-mode').addEventListener('change', () => { this.cancelRoadRampDraft(); this.updateLayerControls(); this.renderOverlay(); });
    for (const id of ['road-ramp-width', 'road-ramp-shoulder', 'road-ramp-ratio', 'road-ramp-start-landing', 'road-ramp-end-landing', 'road-ramp-side-ratio', 'road-ramp-max-side-width', 'road-ramp-side-roundness']) {
      $(id).addEventListener('input', () => { writePreference(`jkr-terrain-${id}`, $(id).value); this.updateRoadRampUi(); this.renderOverlay(); });
    }
    for (const id of ['road-ramp-smooth-sides', 'road-ramp-follow-terrain']) {
      $(id).addEventListener('change', () => { writePreference(`jkr-terrain-${id}`, String($(id).checked)); this.updateRoadRampUi(); this.renderOverlay(); });
    }
    $('road-ramp-type').addEventListener('change', () => { this.updateRoadRampUi(); this.renderOverlay(); });
    $('road-ramp-label').addEventListener('input', () => this.updateRoadRampUi());
    $('road-ramp-finish').addEventListener('click', () => this.finishRoadRampDraft());
    $('road-ramp-undo-point').addEventListener('click', () => this.removeRoadRampPoint());
    $('road-ramp-cancel').addEventListener('click', () => this.cancelRoadRampDraft());
    for (const id of ['brush-slope-width', 'brush-base-width', 'brush-base-intensity', 'brush-profile-shape', 'brush-terrace-steps']) $(id).addEventListener('input', () => { this.updateBrushProfileUi(); this.renderOverlay(); });
    $('new-project').addEventListener('click', () => this.newProject()); $('save-project').addEventListener('click', () => this.saveProject());
    $('load-project').addEventListener('change', (event) => this.loadProject(event));
    $('compile-preview').addEventListener('click', () => this.compile(false)); $('export-schematic').addEventListener('click', () => this.compile(true));
    $('mountain-border-enabled').addEventListener('change', () => { this.updateMountainUi(); this.markDirty(); this.renderOverlay(); });
    $('mountain-canvas-guide').addEventListener('change', () => this.renderOverlay());
    $('prepare-mountain-margin').addEventListener('click', () => this.prepareMountainMargin());
    document.querySelectorAll('[data-marker-tool]').forEach((button) => button.addEventListener('click', () => this.setMarkerTool(button.dataset.markerTool)));
    $('marker-select').addEventListener('click', () => this.setMarkerTool('select'));
    document.querySelectorAll('[data-preview]').forEach((button) => button.addEventListener('click', () => this.selectPreview(button.dataset.preview)));

    for (const id of ['width', 'length', 'schematic-height', 'min-height', 'max-height', 'sea-level']) $(id).addEventListener('input', () => { this.updateVoxelBudget(); this.updatePlateauUi(); });
    for (const id of ['project-name', 'seed', 'schematic-height', 'min-height', 'max-height', 'sea-level', 'modifier-range', 'shore-width', 'max-walk-slope', 'surface-depth', 'data-version', 'mountain-outer-width', 'mountain-inner-transition', 'mountain-height', 'mountain-irregularity', 'mountain-roughness', 'mountain-exit-width', 'mountain-exit-transition']) $(id).addEventListener('input', () => { this.markDirty(); this.updateMountainUi(); this.renderOverlay(); });
    document.addEventListener('keydown', (event) => {
      const editable = ['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement?.tagName);
      if (!editable && (event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z') { event.preventDefault(); event.shiftKey ? this.redo() : this.undo(); }
      if (!editable && (event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'y') { event.preventDefault(); this.redo(); }
      if (event.key === 'Escape') { this.setMarkerTool(null); this.cancelPlateauHeightPicker(); this.cancelRoadRampDraft(); }
    });
  }

  setActiveLayer(name) {
    if (!LAYERS[name]) return; if (name !== 'roads') this.cancelRoadRampDraft(); this.activeLayer = name; this.markerTool = null; this.cancelPlateauHeightPicker();
    document.querySelectorAll('.layer-row').forEach((row) => row.classList.toggle('active', row.dataset.layer === name));
    document.querySelectorAll('.marker-tools button').forEach((button) => button.classList.remove('active'));
    $('active-layer-title').textContent = LAYERS[name].label; this.updateLayerControls(); this.render();
  }

  updateLayerControls() {
    const kind = LAYERS[this.activeLayer].kind; const plateauMode = kind === 'plateau'; const roadLayer = kind === 'roads'; const rampMode = roadLayer && $('road-tool-mode').value === 'ramp';
    $('brush-panel-title').textContent = plateauMode ? 'Herramienta de meseta' : roadLayer ? 'Herramientas de camino' : 'Pincel';
    $('plateau-tool-panel').hidden = !plateauMode; $('road-ramp-panel').hidden = !roadLayer; $('standard-brush-panel').hidden = plateauMode || rampMode;
    $('road-ramp-fields').hidden = !rampMode;
    const action = $('brush-action'); action.replaceChildren();
    for (const [value, label] of ACTIONS[kind]) { const option = document.createElement('option'); option.value = value; option.textContent = label; action.append(option); }
    if (plateauMode) $('stroke-mode').value = 'free';
    this.updateValueOptions(); this.updateBrushProfileUi(); this.updatePlateauUi(); this.updateRoadRampUi();
  }

  updateValueOptions() {
    const kind = LAYERS[this.activeLayer].kind; const select = $('paint-value'); const field = $('value-field'); select.replaceChildren();
    let options = [];
    if (kind === 'category') options = Array.from({ length: 15 }, (_, index) => [String(index + 1), `Región ${index + 1}`]);
    else if (kind === 'material') options = MATERIAL_OPTIONS;
    for (const [value, label] of options) { const option = document.createElement('option'); option.value = value; option.textContent = label; select.append(option); }
    field.hidden = !['category', 'material'].includes(kind) || !['paint', 'fill'].includes($('brush-action').value);
    $('stroke-accumulation-field').hidden = kind !== 'modifier';
  }

  updatePlateauUi() {
    if (!$('plateau-height')) return;
    const settings = normalizePlateauSettings({
      targetHeight: $('plateau-height').value,
      plateauRadius: $('plateau-radius').value,
      slopeWidth: $('plateau-slope-width').value,
      supportEnabled: $('plateau-support-enabled').checked,
      supportWidth: $('plateau-support-width').value,
      supportHeightPercent: $('plateau-support-height').value,
      minHeight: $('min-height').value,
      maxHeight: $('max-height').value,
    });
    const heightInput = $('plateau-height'); heightInput.min = String(settings.minHeight); heightInput.max = String(settings.maxHeight); heightInput.value = String(Math.round(settings.targetHeight));
    $('plateau-radius').value = String(Math.round(settings.plateauRadius * 10) / 10);
    $('plateau-slope-width').max = String(Math.max(0, 1024 - settings.plateauRadius)); $('plateau-slope-width').value = String(Math.round(settings.slopeWidth * 10) / 10);
    $('plateau-support-width').max = String(Math.max(0, 1024 - settings.slopeEndRadius)); $('plateau-support-width').value = String(Math.max(1, Math.round((settings.supportWidth || Number($('plateau-support-width').value) || 24) * 10) / 10));
    $('plateau-support-height').value = String(Math.max(1, Math.round((settings.supportHeightPercent || Number($('plateau-support-height').value) || 25) * 10) / 10));
    const supportRequested = $('plateau-support-enabled').checked;
    $('plateau-support-fields').hidden = !supportRequested; $('plateau-support-legend').hidden = !settings.supportEnabled;
    const restoring = $('plateau-action').value === 'restore'; heightInput.disabled = restoring; $('plateau-pick-height').disabled = restoring;
    const effectiveHeight = restoring ? layerValueToHeight(128, settings.minHeight, settings.maxHeight) : Math.round(settings.targetHeight);
    const baseText = `Altura Y ${effectiveHeight} · meseta ${settings.plateauRadius.toFixed(1)} de radio · pendiente ${settings.slopeWidth.toFixed(1)} · final de pendiente ${settings.slopeEndRadius.toFixed(1)}.`;
    const supportText = settings.supportEnabled
      ? ` Soporte exterior: ${settings.supportWidth.toFixed(1)} bloques, altura ${settings.supportHeightPercent.toFixed(0)}%, radio total ${settings.radius.toFixed(1)}.`
      : ' Sin soporte exterior: fuera del círculo blanco no se levanta el terreno.';
    $('plateau-tool-info').textContent = baseText + supportText;
  }

  plateauSettings() {
    const normalized = normalizePlateauSettings({
      targetHeight: $('plateau-height').value,
      plateauRadius: $('plateau-radius').value,
      slopeWidth: $('plateau-slope-width').value,
      supportEnabled: $('plateau-support-enabled').checked,
      supportWidth: $('plateau-support-width').value,
      supportHeightPercent: $('plateau-support-height').value,
      minHeight: $('min-height').value,
      maxHeight: $('max-height').value,
    });
    const action = $('plateau-action').value;
    return { ...normalized, action, targetValue: action === 'restore' ? 128 : heightToLayerValue(normalized.targetHeight, normalized.minHeight, normalized.maxHeight) };
  }

  togglePlateauHeightPicker() {
    if (this.activeLayer !== 'height_base' || $('plateau-action').value === 'restore') return;
    this.markerTool = null; document.querySelectorAll('.marker-tools button').forEach((button) => button.classList.remove('active'));
    this.plateauPickHeight = !this.plateauPickHeight; $('plateau-pick-height').classList.toggle('active', this.plateauPickHeight);
    this.overlay.style.cursor = this.plateauPickHeight ? 'cell' : 'crosshair';
    this.message(this.plateauPickHeight ? 'Haz clic sobre el terreno para copiar su altura base.' : 'Muestreo de altura cancelado.'); this.renderOverlay();
  }

  cancelPlateauHeightPicker() {
    if (!this.plateauPickHeight) return;
    this.plateauPickHeight = false; $('plateau-pick-height')?.classList.remove('active');
    if (!this.markerTool) this.overlay.style.cursor = 'crosshair'; this.renderOverlay();
  }

  samplePlateauHeight(point) {
    const value = this.layers.height_base[point.z * this.width + point.x];
    const height = layerValueToHeight(value, Number($('min-height').value), Number($('max-height').value));
    $('plateau-height').value = String(height); $('plateau-height').dispatchEvent(new Event('input', { bubbles: true }));
    this.plateauPickHeight = false; $('plateau-pick-height').classList.remove('active'); this.overlay.style.cursor = 'crosshair';
    this.message(`Altura base Y ${height} tomada desde X ${point.x}, Z ${point.z}.`); this.renderOverlay();
  }

  roadRampSettings() {
    return normalizeRoadRampSettings({
      roadType: $('road-ramp-type').value,
      width: $('road-ramp-width').value,
      shoulderWidth: $('road-ramp-shoulder').value,
      slopeRatio: $('road-ramp-ratio').value,
      startLanding: $('road-ramp-start-landing').value,
      endLanding: $('road-ramp-end-landing').value,
      smoothSides: $('road-ramp-smooth-sides').checked,
      sideSlopeRatio: $('road-ramp-side-ratio').value,
      maxSideWidth: $('road-ramp-max-side-width').value,
      sideRoundness: $('road-ramp-side-roundness').value,
      followTerrain: $('road-ramp-follow-terrain').checked,
    });
  }

  sourceHeightAt(point) {
    const x = clamp(Math.round(point.x), 0, this.width - 1); const z = clamp(Math.round(point.z), 0, this.length - 1); const index = z * this.width + x;
    const minHeight = Number($('min-height').value); const maxHeight = Number($('max-height').value); const modifierRange = Number($('modifier-range').value);
    const base = minHeight + this.layers.height_base[index] / 255 * (maxHeight - minHeight);
    const modifier = (this.layers.height_modifier[index] - 128) / 127 * modifierRange;
    return clamp(base + modifier, minHeight, maxHeight);
  }

  roadRampAnalysis(points = this.roadRampDraft) {
    return analyzeRoadRamp(points, this.roadRampSettings(), (point) => this.sourceHeightAt(point));
  }

  updateRoadRampUi() {
    if (!$('road-ramp-fields')) return;
    const active = this.activeLayer === 'roads' && $('road-tool-mode').value === 'ramp';
    $('road-ramp-fields').hidden = !active;
    if (!active) { this.renderRoadRampList(); return; }
    const analysis = this.roadRampAnalysis(); const count = this.roadRampDraft.length;
    $('road-ramp-smoothing-fields').hidden = !analysis.settings.smoothSides;
    $('road-ramp-undo-point').disabled = count === 0;
    $('road-ramp-cancel').disabled = count === 0 && !this.roadRampEditingId;
    $('road-ramp-finish').disabled = !analysis.valid;
    if (count === 0) $('road-ramp-info').textContent = 'Haz clic en el terreno bajo, añade puntos siguiendo el recorrido y termina sobre la meseta.';
    else if (count === 1) $('road-ramp-info').textContent = `Inicio Y ${analysis.startHeight?.toFixed?.(1) ?? this.sourceHeightAt(this.roadRampDraft[0]).toFixed(1)} · añade el punto final o puntos intermedios.`;
    else {
      const actual = Number.isFinite(analysis.actualRatio) ? `1:${analysis.actualRatio.toFixed(2)}` : 'plana';
      const state = analysis.valid ? 'Válida' : `No válida: requiere ${analysis.requiredLength.toFixed(1)} bloques`;
      const sides = analysis.settings.smoothSides ? ` · costados suaves hasta ${analysis.estimatedSideWidth.toFixed(1)} bloques` : ` · transición fija ${analysis.settings.shoulderWidth}`;
      $('road-ramp-info').textContent = `${state} · recorrido ${analysis.length.toFixed(1)} · Y ${analysis.startHeight.toFixed(1)} → ${analysis.endHeight.toFixed(1)} · desnivel ${analysis.heightDifference.toFixed(1)} · pendiente real ${actual}${sides}.`;
    }
    this.renderRoadRampList();
  }

  addRoadRampPoint(point) {
    if (this.locked.roads) { this.message('La capa Caminos está bloqueada.'); return; }
    const next = { x: point.x, z: point.z };
    const previous = this.roadRampDraft.at(-1);
    if (previous && Math.hypot(previous.x - next.x, previous.z - next.z) < 1) { this.message('El nuevo punto debe estar separado del anterior.', true); return; }
    if (this.roadRampDraft.length >= 64) { this.message('Una rampa admite como máximo 64 puntos.', true); return; }
    this.roadRampDraft.push(next); this.updateRoadRampUi(); this.renderOverlay();
    this.message(this.roadRampDraft.length === 1 ? 'Inicio fijado. Continúa haciendo clic hasta llegar a la meseta.' : `Punto ${this.roadRampDraft.length} añadido. Finaliza cuando el estado sea válido.`);
  }

  removeRoadRampPoint() {
    if (!this.roadRampDraft.length) return; this.roadRampDraft.pop(); this.updateRoadRampUi(); this.renderOverlay();
  }

  cancelRoadRampDraft(render = true) {
    this.roadRampDraft = []; this.roadRampEditingId = null; if ($('road-ramp-label')) $('road-ramp-label').value = ''; if (render) { this.updateRoadRampUi(); this.renderOverlay(); }
  }

  finishRoadRampDraft() {
    const analysis = this.roadRampAnalysis();
    if (!analysis.valid) { this.message(analysis.reason || 'La rampa no tiene longitud suficiente.', true); return; }
    const settings = analysis.settings; const before = structuredClone(this.roadRamps); const editingId = this.roadRampEditingId;
    const current = editingId ? this.roadRamps.find((ramp) => ramp.id === editingId) : null;
    const id = current?.id || createRoadRampId();
    const fallbackName = `Rampa ${editingId ? this.roadRamps.findIndex((item) => item.id === editingId) + 1 : this.roadRamps.length + 1}`;
    const ramp = {
      id, label: $('road-ramp-label').value.trim().slice(0, 80) || current?.label || fallbackName,
      road_type: settings.roadType, points: structuredClone(this.roadRampDraft), width: settings.width,
      shoulder_width: settings.shoulderWidth, slope_ratio: settings.slopeRatio,
      start_landing: settings.startLanding, end_landing: settings.endLanding,
      smooth_sides: settings.smoothSides, side_slope_ratio: settings.sideSlopeRatio,
      max_side_width: settings.maxSideWidth, side_roundness: settings.sideRoundness,
      follow_terrain: settings.followTerrain,
    };
    if (editingId) this.roadRamps = this.roadRamps.map((item) => item.id === editingId ? ramp : item); else this.roadRamps.push(ramp);
    this.selectedRoadRampId = id; this.roadRampDraft = []; this.roadRampEditingId = null; $('road-ramp-label').value = '';
    this.pushHistory({ type: 'roadRamps', before, after: structuredClone(this.roadRamps) }); this.renderRoadRampList(); this.updateRoadRampUi(); this.renderOverlay();
    this.message(`${editingId ? 'Rampa actualizada' : 'Rampa creada'}: ${ramp.label}. Compila la vista para comprobar los escalones reales.`);
  }

  editRoadRamp(id) {
    const ramp = this.roadRamps.find((item) => item.id === id); if (!ramp) return;
    this.selectedRoadRampId = id; this.roadRampEditingId = id; this.roadRampDraft = structuredClone(ramp.points);
    $('road-tool-mode').value = 'ramp'; $('road-ramp-label').value = ramp.label || '';
    $('road-ramp-type').value = ramp.road_type; $('road-ramp-width').value = ramp.width; $('road-ramp-shoulder').value = ramp.shoulder_width;
    $('road-ramp-ratio').value = ramp.slope_ratio; $('road-ramp-start-landing').value = ramp.start_landing; $('road-ramp-end-landing').value = ramp.end_landing;
    $('road-ramp-smooth-sides').checked = Boolean(ramp.smooth_sides); $('road-ramp-side-ratio').value = ramp.side_slope_ratio ?? 2;
    $('road-ramp-max-side-width').value = ramp.max_side_width ?? 24; $('road-ramp-side-roundness').value = ramp.side_roundness ?? 65;
    $('road-ramp-follow-terrain').checked = ramp.follow_terrain !== false;
    this.updateLayerControls(); this.renderOverlay(); this.message('Rampa cargada para edición. Puedes quitar o agregar puntos y finalizar para reemplazarla.');
  }

  deleteRoadRamp(id) {
    const ramp = this.roadRamps.find((item) => item.id === id); if (!ramp || !confirm(`¿Eliminar la rampa «${ramp.label || ramp.id}»?`)) return;
    const before = structuredClone(this.roadRamps); this.roadRamps = this.roadRamps.filter((item) => item.id !== id); if (this.roadRampEditingId === id) this.cancelRoadRampDraft(false); if (this.selectedRoadRampId === id) this.selectedRoadRampId = null;
    this.pushHistory({ type: 'roadRamps', before, after: structuredClone(this.roadRamps) }); this.renderRoadRampList(); this.renderOverlay();
  }

  renderRoadRampList() {
    const list = $('road-ramp-list'); if (!list) return; list.replaceChildren();
    if (!this.roadRamps.length) { const empty = document.createElement('div'); empty.className = 'empty-list'; empty.textContent = 'Aún no hay rampas.'; list.append(empty); return; }
    for (const ramp of this.roadRamps) {
      const item = document.createElement('div'); item.className = `road-ramp-item${ramp.id === this.selectedRoadRampId ? ' selected' : ''}`;
      const content = document.createElement('button'); content.type = 'button'; content.className = 'road-ramp-select'; content.addEventListener('click', () => { this.selectedRoadRampId = ramp.id; this.renderRoadRampList(); this.renderOverlay(); });
      const title = document.createElement('strong'); title.textContent = ramp.label || ramp.id; const meta = document.createElement('small');
      const sideMeta = ramp.smooth_sides ? `suave 1:${ramp.side_slope_ratio ?? 2}, máx. ${ramp.max_side_width ?? 24}` : `lateral fijo ${ramp.shoulder_width}`;
      meta.textContent = `${ramp.road_type === 'primary' ? 'Principal' : 'Secundario'} · ancho ${ramp.width} · ${sideMeta} · subida 1:${ramp.slope_ratio} · ${ramp.points.length} puntos`;
      content.append(title, meta); const actions = document.createElement('div'); actions.className = 'road-ramp-item-actions';
      const edit = document.createElement('button'); edit.type = 'button'; edit.textContent = 'Editar'; edit.addEventListener('click', () => this.editRoadRamp(ramp.id));
      const remove = document.createElement('button'); remove.type = 'button'; remove.textContent = 'Eliminar'; remove.className = 'danger-soft'; remove.addEventListener('click', () => this.deleteRoadRamp(ramp.id));
      actions.append(edit, remove); item.append(content, actions); list.append(item);
    }
  }

  drawRoadRampPath(ctx, points, settings, selected = false, draft = false) {
    if (!points?.length) return; const pathPoints = [...points];
    if (draft && this.hover && pathPoints.length) pathPoints.push({ x: this.hover.x, z: this.hover.z });
    if (pathPoints.length < 2) {
      ctx.save(); ctx.fillStyle = '#70dc91'; ctx.beginPath(); ctx.arc(pathPoints[0].x, pathPoints[0].z, Math.max(1.5, settings.width * .2), 0, Math.PI * 2); ctx.fill(); ctx.restore(); return;
    }
    const trace = () => { ctx.beginPath(); ctx.moveTo(pathPoints[0].x, pathPoints[0].z); for (const point of pathPoints.slice(1)) ctx.lineTo(point.x, point.z); };
    ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (draft) ctx.setLineDash([Math.max(2, this.width / 256), Math.max(1.5, this.width / 384)]);
    const previewSideWidth = settings.smoothSides ? settings.maxSideWidth : settings.shoulderWidth;
    ctx.strokeStyle = selected ? '#66f19c88' : '#50c77b55'; ctx.lineWidth = settings.width + previewSideWidth * 2; trace(); ctx.stroke();
    ctx.strokeStyle = settings.roadType === 'secondary' ? '#b8895eee' : '#f0c774ee'; ctx.lineWidth = settings.width; trace(); ctx.stroke();
    ctx.setLineDash([]); ctx.fillStyle = '#d9f4e2'; for (const point of points) { ctx.beginPath(); ctx.arc(point.x, point.z, Math.max(1.1, settings.width * .14), 0, Math.PI * 2); ctx.fill(); }
    const endpointRadius = Math.max(1.6, settings.width * .22); ctx.fillStyle = '#6dbaff'; ctx.beginPath(); ctx.arc(points[0].x, points[0].z, endpointRadius, 0, Math.PI * 2); ctx.fill();
    if (points.length > 1) { ctx.fillStyle = '#ff9b66'; ctx.beginPath(); ctx.arc(points.at(-1).x, points.at(-1).z, endpointRadius, 0, Math.PI * 2); ctx.fill(); }
    ctx.restore();
  }

  drawRoadRamps(ctx) {
    if (!this.visibility.roads && this.activeLayer !== 'roads') return;
    for (const ramp of this.roadRamps) this.drawRoadRampPath(ctx, ramp.points, normalizeRoadRampSettings({ roadType: ramp.road_type, width: ramp.width, shoulderWidth: ramp.shoulder_width, slopeRatio: ramp.slope_ratio, startLanding: ramp.start_landing, endLanding: ramp.end_landing, smoothSides: ramp.smooth_sides, sideSlopeRatio: ramp.side_slope_ratio, maxSideWidth: ramp.max_side_width, sideRoundness: ramp.side_roundness, followTerrain: ramp.follow_terrain }), ramp.id === this.selectedRoadRampId, false);
    if (this.activeLayer === 'roads' && $('road-tool-mode').value === 'ramp' && this.roadRampDraft.length) this.drawRoadRampPath(ctx, this.roadRampDraft, this.roadRampSettings(), true, true);
  }

  updateBrushProfileUi() {
    const kind = LAYERS[this.activeLayer].kind;
    const heightLayer = kind === 'modifier';
    const advanced = heightLayer && $('elevation-profile-enabled').checked;
    $('elevation-profile-enabled-field').hidden = !heightLayer;
    $('elevation-profile-fields').hidden = !advanced;
    $('brush-core-mode-field').hidden = advanced;

    let diameter = clamp(Number($('brush-size').value) || 1, 1, 2048);
    let totalRadius = Math.max(0.5, diameter / 2);
    let coreRadius = 0;
    let slopeWidth = 0;
    let baseWidth = 0;
    let baseIntensity = 0;

    if (advanced) {
      const profile = normalizeElevationProfile({
        coreRadius: $('brush-core-radius').value,
        slopeWidth: $('brush-slope-width').value,
        baseEnabled: $('brush-base-enabled').checked,
        baseWidth: $('brush-base-width').value,
        baseIntensity: $('brush-base-intensity').value,
        profile: $('brush-profile-shape').value,
        terraceSteps: $('brush-terrace-steps').value,
      });
      coreRadius = profile.coreRadius; slopeWidth = profile.slopeWidth; baseWidth = profile.baseWidth; baseIntensity = profile.baseIntensity;
      $('brush-core-radius').value = String(Math.round(coreRadius * 10) / 10); $('brush-slope-width').value = String(Math.round(slopeWidth * 10) / 10); $('brush-base-width').value = String(Math.round(baseWidth * 10) / 10);
      totalRadius = Math.max(0.5, profile.radius); diameter = Math.min(2048, totalRadius * 2);
      $('brush-size').value = String(Math.round(diameter * 10) / 10);
      $('brush-size').disabled = true; $('brush-hardness').disabled = true;
      $('brush-core-radius').disabled = false; $('brush-core-radius').max = '1024';
      $('brush-base-fields').hidden = !$('brush-base-enabled').checked;
      $('brush-terrace-steps-field').hidden = $('brush-profile-shape').value !== 'terraced';
      const baseText = $('brush-base-enabled').checked ? ` · base ${baseWidth.toFixed(1)} a ${(baseIntensity * 100).toFixed(0)}%` : ' · sin base exterior';
      $('brush-profile-info').textContent = `Radio exterior ${totalRadius.toFixed(1)} · núcleo ${coreRadius.toFixed(1)} · talud ${slopeWidth.toFixed(1)}${baseText} · diámetro ${diameter.toFixed(1)} bloques.`;
      return;
    }

    $('brush-size').disabled = false;
    const direct = $('brush-core-mode').checked;
    const coreInput = $('brush-core-radius'); coreInput.max = String(totalRadius);
    if (direct) {
      coreRadius = clamp(Number(coreInput.value) || 0, 0, totalRadius);
      coreInput.value = String(Math.round(coreRadius * 10) / 10);
    } else {
      coreRadius = totalRadius * clamp(Number($('brush-hardness').value) / 100, 0, 1);
      coreInput.value = String(Math.round(coreRadius * 10) / 10);
    }
    coreInput.disabled = !direct; $('brush-hardness').disabled = direct;
    const transition = Math.max(0, totalRadius - coreRadius);
    const equivalentHardness = totalRadius > 0 ? coreRadius / totalRadius * 100 : 0;
    $('brush-profile-info').textContent = `Radio total ${totalRadius.toFixed(1)} · núcleo ${coreRadius.toFixed(1)} · transición ${transition.toFixed(1)} bloques · dureza equivalente ${equivalentHardness.toFixed(0)}%.`;
  }

  initializePresetManagers() {
    for (const group of Object.keys(PRESET_GROUPS)) {
      $(`${group}-preset-save`).addEventListener('click', () => this.savePreset(group));
      $(`${group}-preset-load`).addEventListener('click', () => this.loadPreset(group));
      $(`${group}-preset-delete`).addEventListener('click', () => this.deletePreset(group));
      $(`${group}-preset-select`).addEventListener('change', () => { const name = $(`${group}-preset-select`).value; if (name) $(`${group}-preset-name`).value = name; });
      this.refreshPresetSelect(group);
    }
  }

  presetStore(group) {
    const definition = PRESET_GROUPS[group];
    if (!definition) return {};
    try { const value = JSON.parse(readPreference(definition.storageKey, '{}')); return value && typeof value === 'object' && !Array.isArray(value) ? value : {}; }
    catch (_) { return {}; }
  }

  writePresetStore(group, store) { writePreference(PRESET_GROUPS[group].storageKey, JSON.stringify(store)); }

  snapshotPreset(group) {
    const output = {};
    for (const [id, mode] of PRESET_GROUPS[group].fields) output[id] = mode === 'checked' ? $(id).checked : $(id).value;
    return output;
  }

  refreshPresetSelect(group, selected = '') {
    const select = $(`${group}-preset-select`); const store = this.presetStore(group); select.replaceChildren();
    const empty = document.createElement('option'); empty.value = ''; empty.textContent = 'Selecciona un preset'; select.append(empty);
    for (const name of Object.keys(store).sort((a, b) => a.localeCompare(b, 'es'))) { const option = document.createElement('option'); option.value = name; option.textContent = name; select.append(option); }
    if (selected && store[selected]) select.value = selected;
  }

  savePreset(group) {
    const definition = PRESET_GROUPS[group]; const input = $(`${group}-preset-name`); const name = input.value.trim().slice(0, 40);
    if (!name) { this.message(`Escribe un nombre para el preset de ${definition.label}.`, true); input.focus(); return; }
    const store = this.presetStore(group); if (store[name] && !confirm(`El preset «${name}» ya existe. ¿Reemplazarlo?`)) return;
    store[name] = this.snapshotPreset(group); this.writePresetStore(group, store); this.refreshPresetSelect(group, name); this.message(`Preset de ${definition.label} «${name}» guardado en este navegador.`);
  }

  loadPreset(group) {
    const definition = PRESET_GROUPS[group]; const select = $(`${group}-preset-select`); const name = select.value; const preset = this.presetStore(group)[name];
    if (!name || !preset) { this.message(`Selecciona un preset de ${definition.label}.`, true); return; }
    for (const [id, mode] of definition.fields) {
      if (!(id in preset) || !$(id)) continue;
      if (mode === 'checked') $(id).checked = Boolean(preset[id]); else $(id).value = preset[id];
    }
    if (group === 'brush') { this.updateBrushProfileUi(); this.updatePlateauUi(); this.updateLayerControls(); this.renderOverlay(); }
    else if (group === 'mountain') { this.updateMountainUi(); this.renderOverlay(); this.markDirty(); }
    else { this.updateVoxelBudget(); this.markDirty(); }
    $(`${group}-preset-name`).value = name; this.message(`Preset de ${definition.label} «${name}» cargado.`);
  }

  deletePreset(group) {
    const definition = PRESET_GROUPS[group]; const select = $(`${group}-preset-select`); const name = select.value; const store = this.presetStore(group);
    if (!name || !store[name]) { this.message(`Selecciona un preset de ${definition.label} para borrarlo.`, true); return; }
    if (!confirm(`¿Borrar el preset «${name}»?`)) return;
    delete store[name]; this.writePresetStore(group, store); this.refreshPresetSelect(group); $(`${group}-preset-name`).value = ''; this.message(`Preset «${name}» eliminado.`);
  }

  randomizeSeed() {
    const maximum = 2147483647; let value;
    if (globalThis.crypto?.getRandomValues) {
      const random = new Uint32Array(1); globalThis.crypto.getRandomValues(random); value = random[0] & maximum;
    } else value = Math.floor(Math.random() * (maximum + 1));
    $('seed').value = String(value); $('seed').dispatchEvent(new Event('input', { bubbles: true }));
    this.message(`Semilla aleatoria generada: ${value}.`);
  }

  eventPoint(event) {
    const rect = this.overlay.getBoundingClientRect();
    return { x: clamp(Math.floor((event.clientX - rect.left) / rect.width * this.width), 0, this.width - 1), z: clamp(Math.floor((event.clientY - rect.top) / rect.height * this.length), 0, this.length - 1) };
  }

  pointerStart(event) {
    event.preventDefault(); const point = this.eventPoint(event); this.hover = point;
    if (this.plateauPickHeight && this.activeLayer === 'height_base') { this.samplePlateauHeight(point); return; }
    if (this.markerTool) {
      try { this.handleMarkerClick(point); }
      catch (error) { console.error(error); this.message(`No se pudo colocar el marcador: ${error.message || error}`, true); }
      return;
    }
    if (this.activeLayer === 'roads' && $('road-tool-mode').value === 'ramp') { this.addRoadRampPoint(point); return; }
    if (this.locked[this.activeLayer]) { this.message('La capa está bloqueada.'); return; }
    this.pointerDown = true; this.overlay.setPointerCapture(event.pointerId); this.currentChanges = new Map(); this.strokeBaseValues = new Map(); this.strokeInfluence = new Map();
    if ($('brush-action').value === 'fill' && ['mask', 'category', 'material'].includes(LAYERS[this.activeLayer].kind)) {
      this.floodFill(point.x, point.z); this.finishStroke(); this.pointerDown = false; return;
    }
    if ($('stroke-mode').value === 'line') this.lineStart = point;
    else this.paintSegment(point, point);
    this.renderOverlay();
  }

  pointerMove(event) {
    const point = this.eventPoint(event); $('cursor-info').textContent = `X ${point.x} · Z ${point.z}`;
    const previous = this.hover; this.hover = point;
    if (this.pointerDown && !this.markerTool && $('stroke-mode').value === 'free' && previous) this.paintSegment(previous, point);
    this.renderOverlay();
  }

  pointerEnd(event) {
    if (!this.pointerDown) return;
    const point = this.eventPoint(event);
    if ($('stroke-mode').value === 'line' && this.lineStart) this.paintSegment(this.lineStart, point);
    this.pointerDown = false; this.lineStart = null; try { this.overlay.releasePointerCapture(event.pointerId); } catch (_) { /* no-op */ }
    this.finishStroke(); this.renderOverlay();
  }

  beginChange(index) {
    if (!this.currentChanges.has(index)) this.currentChanges.set(index, this.layers[this.activeLayer][index]);
  }

  setCell(index, value) {
    const next = clamp(Math.round(value), 0, 255); const layer = this.layers[this.activeLayer]; if (layer[index] === next) return;
    this.beginChange(index); layer[index] = next; if (this.activeLayer === 'playable') { this.playableBoundaryCache = null; this.playableBoundaryPathCache = null; }
  }

  brushSettings() {
    const kind = LAYERS[this.activeLayer].kind;
    if (kind === 'plateau') {
      const plateau = this.plateauSettings();
      return {
        radius: Math.max(1, plateau.radius), coreRadius: plateau.plateauRadius, hardness: 1,
        plateauMode: true, plateau, advanced: false, elevationProfile: null, strictClip: true,
        opacity: 1, strength: 0, shape: 'circle', action: plateau.action, value: plateau.targetValue,
      };
    }
    const advanced = kind === 'modifier' && $('elevation-profile-enabled').checked;
    let radius; let coreRadius; let elevationProfile = null;
    if (advanced) {
      elevationProfile = normalizeElevationProfile({
        coreRadius: $('brush-core-radius').value,
        slopeWidth: $('brush-slope-width').value,
        baseEnabled: $('brush-base-enabled').checked,
        baseWidth: $('brush-base-width').value,
        baseIntensity: $('brush-base-intensity').value,
        profile: $('brush-profile-shape').value,
        terraceSteps: $('brush-terrace-steps').value,
      });
      radius = Math.max(0.5, elevationProfile.radius); coreRadius = elevationProfile.coreRadius;
    } else {
      radius = Math.max(0.5, Number($('brush-size').value) / 2);
      const directCore = $('brush-core-mode').checked;
      coreRadius = directCore ? clamp(Number($('brush-core-radius').value) || 0, 0, radius) : radius * clamp(Number($('brush-hardness').value) / 100, 0, 1);
    }
    return {
      radius, coreRadius, hardness: radius > 0 ? coreRadius / radius : 0, plateauMode: false, plateau: null, advanced, elevationProfile,
      strictClip: $('brush-strict-clip').checked,
      opacity: clamp(Number($('brush-opacity').value) / 100, 0.01, 1), strength: clamp(Number($('brush-strength').value), 1, 64), shape: $('brush-shape').value,
      action: $('brush-action').value, value: Number($('paint-value').value || 0),
    };
  }

  paintSegment(start, end) {
    const settings = this.brushSettings(); const distance = Math.hypot(end.x - start.x, end.z - start.z);
    const steps = Math.max(1, Math.ceil(distance / Math.max(0.7, settings.radius * 0.28)));
    for (let step = 0; step <= steps; step += 1) { const t = step / steps; this.paintDisk(start.x + (end.x - start.x) * t, start.z + (end.z - start.z) * t, settings); }
    this.markDirty(); this.scheduleRender();
  }

  paintDisk(cx, cz, settings) {
    const { radius, hardness, opacity, strength, shape, action, value, plateauMode, plateau, advanced, elevationProfile, strictClip } = settings;
    const x0 = Math.max(0, Math.floor(cx - radius)); const x1 = Math.min(this.width - 1, Math.ceil(cx + radius));
    const z0 = Math.max(0, Math.floor(cz - radius)); const z1 = Math.min(this.length - 1, Math.ceil(cz + radius));
    const layer = this.layers[this.activeLayer]; const kind = LAYERS[this.activeLayer].kind;
    for (let z = z0; z <= z1; z += 1) for (let x = x0; x <= x1; x += 1) {
      const dx = Math.abs(x - cx); const dz = Math.abs(z - cz); const distance = shape === 'square' ? Math.max(dx, dz) : Math.hypot(dx, dz);
      const edgeAllowance = strictClip ? 0 : 0.5; if (distance > radius + edgeAllowance) continue;
      let influence;
      if (plateauMode) influence = plateauInfluence(distance, plateau);
      else if (advanced) influence = elevationProfileInfluence(distance, elevationProfile);
      else { const normalized = distance / radius; influence = normalized <= hardness ? 1 : 1 - (normalized - hardness) / Math.max(0.001, 1 - hardness); }
      if (!strictClip && distance > radius) influence *= Math.max(0, 1 - (distance - radius) / Math.max(0.001, edgeAllowance));
      const alpha = clamp(influence * opacity, 0, 1);
      if (alpha <= 0) continue; const index = z * this.width + x; const current = layer[index];
      if (kind === 'mask') {
        if (action === 'add') this.setCell(index, Math.max(current, 255 * alpha)); else if (action === 'erase') this.setCell(index, current * (1 - alpha));
      } else if (kind === 'roads') {
        if (action === 'erase') this.setCell(index, 0); else if (alpha >= 0.18) this.setCell(index, action === 'primary' ? 1 : (current === 1 ? 1 : 2));
      } else if (kind === 'category' || kind === 'material') {
        if (action === 'erase') this.setCell(index, 0); else if (alpha >= 0.2) this.setCell(index, value);
      } else if (kind === 'plateau') {
        if (!this.strokeBaseValues?.has(index)) this.strokeBaseValues?.set(index, current);
        const previousInfluence = this.strokeInfluence?.get(index) || 0;
        if (alpha <= previousInfluence + 0.0001) continue;
        this.strokeInfluence?.set(index, alpha);
        const source = this.strokeBaseValues?.get(index) ?? current;
        this.setCell(index, source + (value - source) * alpha);
      } else if (kind === 'modifier') {
        const accumulate = $('stroke-accumulation').checked || action === 'smooth';
        let source = current; let effectiveAlpha = alpha;
        if (!accumulate) {
          if (!this.strokeBaseValues?.has(index)) this.strokeBaseValues?.set(index, current);
          const previousInfluence = this.strokeInfluence?.get(index) || 0;
          if (alpha <= previousInfluence + 0.0001) continue;
          this.strokeInfluence?.set(index, alpha); source = this.strokeBaseValues?.get(index) ?? current; effectiveAlpha = alpha;
        }
        if (action === 'raise') this.setCell(index, source + strength * effectiveAlpha); else if (action === 'lower') this.setCell(index, source - strength * effectiveAlpha);
        else if (action === 'reset') this.setCell(index, source + (128 - source) * effectiveAlpha);
        else if (action === 'smooth') {
          let total = 0; let count = 0;
          for (let nz = Math.max(0, z - 2); nz <= Math.min(this.length - 1, z + 2); nz += 1) for (let nx = Math.max(0, x - 2); nx <= Math.min(this.width - 1, x + 2); nx += 1) { total += layer[nz * this.width + nx]; count += 1; }
          this.setCell(index, current + (total / count - current) * alpha * 0.65);
        }
      }
    }
  }

  floodFill(x, z) {
    const layer = this.layers[this.activeLayer]; const target = layer[z * this.width + x]; const kind = LAYERS[this.activeLayer].kind; const action = $('brush-action').value;
    let replacement = 0; if (kind === 'mask') replacement = action === 'erase' ? 0 : 255; else replacement = action === 'erase' ? 0 : Number($('paint-value').value || 0);
    if (target === replacement) return; const queue = [z * this.width + x]; const visited = new Uint8Array(layer.length); visited[queue[0]] = 1;
    for (let cursor = 0; cursor < queue.length; cursor += 1) {
      const index = queue[cursor]; if (layer[index] !== target) continue; this.setCell(index, replacement); const px = index % this.width; const pz = Math.floor(index / this.width);
      for (const next of [px > 0 ? index - 1 : -1, px < this.width - 1 ? index + 1 : -1, pz > 0 ? index - this.width : -1, pz < this.length - 1 ? index + this.width : -1]) if (next >= 0 && !visited[next]) { visited[next] = 1; if (layer[next] === target) queue.push(next); }
    }
    this.markDirty(); this.scheduleRender();
  }

  finishStroke() {
    if (!this.currentChanges) return; const changes = [];
    for (const [index, oldValue] of this.currentChanges.entries()) { const newValue = this.layers[this.activeLayer][index]; if (oldValue !== newValue) changes.push([index, oldValue, newValue]); }
    if (changes.length) this.pushHistory({ type: 'cells', layer: this.activeLayer, changes });
    this.currentChanges = null; this.strokeBaseValues = null; this.strokeInfluence = null; this.updateHistory();
  }

  pushHistory(operation) { this.undoStack.push(operation); if (this.undoStack.length > this.maxHistory) this.undoStack.shift(); this.redoStack.length = 0; this.markDirty(); this.updateHistory(); }

  applyOperation(operation, direction) {
    if (operation.type === 'cells') { const layer = this.layers[operation.layer]; for (const [index, oldValue, newValue] of operation.changes) layer[index] = direction === 'undo' ? oldValue : newValue; if (operation.layer === 'playable') { this.playableBoundaryCache = null; this.playableBoundaryPathCache = null; } }
    else if (operation.type === 'markers') this.markers = structuredClone(direction === 'undo' ? operation.before : operation.after);
    else if (operation.type === 'roadRamps') { this.roadRamps = structuredClone(direction === 'undo' ? operation.before : operation.after); this.selectedRoadRampId = null; this.cancelRoadRampDraft(false); this.renderRoadRampList(); }
    else if (operation.type === 'roadState') {
      const layer = this.layers.roads; for (const [index, oldValue, newValue] of operation.changes) layer[index] = direction === 'undo' ? oldValue : newValue;
      this.roadRamps = structuredClone(direction === 'undo' ? operation.rampsBefore : operation.rampsAfter); this.selectedRoadRampId = null; this.cancelRoadRampDraft(false); this.renderRoadRampList();
    }
    this.markDirty(); this.render(); this.renderMarkers();
  }

  undo() { const operation = this.undoStack.pop(); if (!operation) return; this.applyOperation(operation, 'undo'); this.redoStack.push(operation); this.updateHistory(); }
  redo() { const operation = this.redoStack.pop(); if (!operation) return; this.applyOperation(operation, 'redo'); this.undoStack.push(operation); this.updateHistory(); }
  updateHistory() { $('history-info').textContent = `Historial: ${this.undoStack.length} · Rehacer: ${this.redoStack.length}`; $('undo').disabled = !this.undoStack.length; $('redo').disabled = !this.redoStack.length; }

  clearLayer() {
    if (this.activeLayer === 'roads') {
      if (!confirm('¿Vaciar los caminos pintados y eliminar todas las rampas viales?')) return;
      const layer = this.layers.roads; const changes = []; const rampsBefore = structuredClone(this.roadRamps);
      for (let index = 0; index < layer.length; index += 1) if (layer[index] !== 0) { changes.push([index, layer[index], 0]); layer[index] = 0; }
      this.roadRamps = []; this.cancelRoadRampDraft(false); this.selectedRoadRampId = null;
      if (changes.length || rampsBefore.length) this.pushHistory({ type: 'roadState', changes, rampsBefore, rampsAfter: [] });
      this.renderRoadRampList(); this.updateHistory(); this.render(); return;
    }
    if (!confirm(`¿Vaciar la capa «${LAYERS[this.activeLayer].label}»?`)) return; const layer = this.layers[this.activeLayer]; const defaultValue = LAYERS[this.activeLayer].default; const changes = [];
    for (let index = 0; index < layer.length; index += 1) if (layer[index] !== defaultValue) { changes.push([index, layer[index], defaultValue]); layer[index] = defaultValue; }
    if (changes.length) this.pushHistory({ type: 'cells', layer: this.activeLayer, changes }); if (this.activeLayer === 'playable') { this.playableBoundaryCache = null; this.playableBoundaryPathCache = null; } this.updateHistory(); this.render();
  }

  showAll() { for (const name of Object.keys(LAYERS)) this.visibility[name] = true; this.buildLayerList(); this.render(); }

  setMarkerTool(tool) {
    this.cancelPlateauHeightPicker(); if (tool) this.cancelRoadRampDraft(); this.markerTool = tool; document.querySelectorAll('.marker-tools button').forEach((button) => button.classList.toggle('active', button.dataset.markerTool === tool || (tool === 'select' && button.id === 'marker-select')));
    const names = { spawn: 'Spawn', exit: 'Salida', poi: 'Punto de interés', select: 'Seleccionar' };
    this.overlay.style.cursor = tool ? (tool === 'select' ? 'pointer' : 'copy') : 'crosshair';
    this.message(tool ? `${names[tool] || tool} activo: haz clic una vez en el lienzo.` : 'Herramienta de marcador desactivada.'); this.renderOverlay();
  }

  playableBoundaryPoints() {
    if (this.playableBoundaryCache) return this.playableBoundaryCache;
    const playable = this.layers.playable; const points = [];
    for (let z = 0; z < this.length; z += 1) for (let x = 0; x < this.width; x += 1) {
      const index = z * this.width + x; if (playable[index] < 128) continue;
      const boundary = x === 0 || z === 0 || x === this.width - 1 || z === this.length - 1
        || playable[index - 1] < 128 || playable[index + 1] < 128
        || playable[index - this.width] < 128 || playable[index + this.width] < 128;
      if (boundary) points.push({ x, z });
    }
    this.playableBoundaryCache = points; return points;
  }

  nearestPlayableBoundary(point) {
    let best = null; let bestDistance = Infinity;
    for (const candidate of this.playableBoundaryPoints()) {
      const distance = (candidate.x - point.x) ** 2 + (candidate.z - point.z) ** 2;
      if (distance < bestDistance) { bestDistance = distance; best = candidate; }
    }
    if (best) return { ...best };
    const candidates = [
      { x: 0, z: point.z, d: point.x }, { x: this.width - 1, z: point.z, d: this.width - 1 - point.x },
      { x: point.x, z: 0, d: point.z }, { x: point.x, z: this.length - 1, d: this.length - 1 - point.z },
    ];
    const fallback = candidates.sort((a, b) => a.d - b.d)[0]; return { x: fallback.x, z: fallback.z };
  }

  markerPreviewPoint(point) { return this.markerTool === 'exit' ? this.nearestPlayableBoundary(point) : point; }

  handleMarkerClick(point) {
    if (this.markerTool === 'select') { const nearest = this.nearestMarker(point); if (nearest) this.message(`${nearest.label} (${nearest.type}) en X ${nearest.x}, Z ${nearest.z}.`); else this.message('No hay ningún marcador cerca de ese punto.'); return; }
    const before = structuredClone(this.markers); const type = this.markerTool; const target = type === 'exit' ? this.nearestPlayableBoundary(point) : point; const { x, z } = target;
    if (type === 'spawn') this.markers = this.markers.filter((marker) => marker.type !== 'spawn');
    const count = this.markers.filter((marker) => marker.type === type).length + 1; const labels = { spawn: 'Spawn principal', exit: `Salida ${count}`, poi: `POI ${count}` };
    const marker = { id: createMarkerId(), type, x, z, label: labels[type], radius: clamp(Number($('marker-radius').value) || 12, 1, 512) };
    this.markers.push(marker);
    this.pushHistory({ type: 'markers', before, after: structuredClone(this.markers) }); this.render(); this.renderMarkers(); this.updateHistory();
    this.message(`${marker.label} colocada en X ${x}, Z ${z}. Pulsa Esc cuando termines.`);
  }

  nearestMarker(point) { let best = null; let distance = Infinity; for (const marker of this.markers) { const current = Math.hypot(marker.x - point.x, marker.z - point.z); if (current < distance && current <= Math.max(8, marker.radius)) { best = marker; distance = current; } } return best; }

  renderMarkers() {
    const list = $('marker-list'); list.replaceChildren();
    for (const marker of this.markers) {
      const item = document.createElement('div'); item.className = 'marker-item';
      const content = document.createElement('div'); content.className = 'marker-content'; const input = document.createElement('input'); input.value = marker.label;
      const typeNames = { spawn: 'Spawn', exit: 'Salida', poi: 'Punto de interés' }; const meta = document.createElement('small'); meta.className = 'marker-meta'; meta.textContent = `${typeNames[marker.type] || marker.type} · X ${marker.x} · Z ${marker.z}`;
      input.addEventListener('change', () => { const before = structuredClone(this.markers); marker.label = input.value.slice(0, 80); this.pushHistory({ type: 'markers', before, after: structuredClone(this.markers) }); this.render(); });
      content.append(input, meta);
      const remove = document.createElement('button'); remove.textContent = 'Eliminar'; remove.addEventListener('click', () => { const before = structuredClone(this.markers); this.markers = this.markers.filter((itemMarker) => itemMarker.id !== marker.id); this.pushHistory({ type: 'markers', before, after: structuredClone(this.markers) }); this.render(); this.renderMarkers(); });
      item.append(content, remove); list.append(item);
    }
  }

  scheduleRender() { if (this.renderQueued) return; this.renderQueued = true; requestAnimationFrame(() => { this.renderQueued = false; this.render(); }); }

  render() {
    const image = this.ctx.createImageData(this.width, this.length); const data = image.data; const mode = $('view-mode').value;
    const base = this.layers.height_base; const modifier = this.layers.height_modifier; const playable = this.layers.playable; const regions = this.layers.regions; const roads = this.layers.roads; const water = this.layers.water; const reserved = this.layers.reserved; const materials = this.layers.materials; const exclusion = this.layers.exclusion;
    for (let index = 0; index < base.length; index += 1) {
      let r = 48 + base[index] * 0.48; let g = 58 + base[index] * 0.55; let b = 49 + base[index] * 0.42;
      const activeOnly = mode === 'current'; const active = this.activeLayer;
      if (activeOnly) {
        const value = this.layers[active][index]; const kind = LAYERS[active].kind;
        if (active === 'regions') [r, g, b] = REGION_COLORS[value % REGION_COLORS.length];
        else if (active === 'roads') [r, g, b] = value === 1 ? [210, 173, 113] : value === 2 ? [142, 104, 67] : [24, 29, 25];
        else if (active === 'water') [r, g, b] = value ? [52, 112, 170] : [24, 29, 25];
        else if (active === 'materials') { const colors = [[35, 40, 36], [73, 128, 67], [127, 88, 56], [105, 108, 112], [194, 174, 112], [225, 232, 235], [130, 126, 115], [52, 112, 170]]; [r, g, b] = colors[value] || colors[0]; }
        else if (active === 'height_modifier') { const delta = value - 128; r = 90 + Math.max(0, delta) * 1.2; g = 90 + Math.min(0, delta) * -0.3; b = 90 + Math.max(0, -delta) * 1.2; }
        else { r = g = b = value; }
      } else {
        if (this.visibility.regions) { const color = REGION_COLORS[regions[index] % REGION_COLORS.length]; r = r * .76 + color[0] * .24; g = g * .76 + color[1] * .24; b = b * .76 + color[2] * .24; }
        if (this.visibility.height_modifier) { const delta = modifier[index] - 128; r += Math.max(0, delta) * .22; b += Math.max(0, -delta) * .25; }
        if (this.visibility.materials && materials[index]) { const colors = REGION_COLORS; const color = colors[(materials[index] + 7) % colors.length]; r = r * .65 + color[0] * .35; g = g * .65 + color[1] * .35; b = b * .65 + color[2] * .35; }
        if (this.visibility.water && water[index]) { const alpha = water[index] / 255 * .8; r = r * (1 - alpha) + 46 * alpha; g = g * (1 - alpha) + 105 * alpha; b = b * (1 - alpha) + 170 * alpha; }
        if (this.visibility.reserved && reserved[index]) { const alpha = reserved[index] / 255 * .55; r = r * (1 - alpha) + 201 * alpha; g = g * (1 - alpha) + 115 * alpha; b = b * (1 - alpha) + 211 * alpha; }
        if (this.visibility.roads && roads[index]) [r, g, b] = roads[index] === 1 ? [204, 169, 112] : [136, 98, 65];
        if (this.visibility.exclusion && exclusion[index]) { r = 185; g *= .5; b *= .5; }
        if (this.visibility.playable && playable[index] < 128) [r, g, b] = [40, 42, 44];
      }
      const offset = index * 4; data[offset] = clamp(r, 0, 255); data[offset + 1] = clamp(g, 0, 255); data[offset + 2] = clamp(b, 0, 255); data[offset + 3] = 255;
    }
    this.ctx.putImageData(image, 0, 0); this.renderOverlay();
  }

  renderOverlay() {
    const ctx = this.overlayCtx; ctx.clearRect(0, 0, this.width, this.length);
    if ($('mountain-canvas-guide').checked) this.drawMountainGuide(ctx);
    this.drawRoadRamps(ctx);
    for (const marker of this.markers) {
      const color = marker.type === 'spawn' ? '#f1df5d' : marker.type === 'exit' ? '#ff5f5f' : '#da88e4'; const radius = Math.max(3, marker.radius);
      ctx.save(); ctx.strokeStyle = '#101713'; ctx.lineWidth = Math.max(3, this.width / 180); ctx.beginPath(); ctx.arc(marker.x + .5, marker.z + .5, radius, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = color; ctx.lineWidth = Math.max(1.5, this.width / 360); ctx.beginPath(); ctx.arc(marker.x + .5, marker.z + .5, radius, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = color; ctx.beginPath(); ctx.arc(marker.x + .5, marker.z + .5, Math.max(2.5, radius * .22), 0, Math.PI * 2); ctx.fill(); ctx.restore();
    }
    if (this.hover && this.markerTool && this.markerTool !== 'select') {
      const preview = this.markerPreviewPoint(this.hover); const color = this.markerTool === 'spawn' ? '#f1df5d' : this.markerTool === 'exit' ? '#ff5f5f' : '#da88e4'; const radius = Math.max(3, Number($('marker-radius').value) || 12);
      ctx.save(); ctx.setLineDash([Math.max(2, this.width / 128), Math.max(2, this.width / 128)]); ctx.strokeStyle = color; ctx.lineWidth = Math.max(1.5, this.width / 360); ctx.beginPath(); ctx.arc(preview.x + .5, preview.z + .5, radius, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
    }
    if ($('grid-toggle').checked) { ctx.strokeStyle = '#ffffff24'; ctx.lineWidth = .5; const step = 16; for (let x = 0; x <= this.width; x += step) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, this.length); ctx.stroke(); } for (let z = 0; z <= this.length; z += step) { ctx.beginPath(); ctx.moveTo(0, z); ctx.lineTo(this.width, z); ctx.stroke(); } }
    if (this.hover && !this.markerTool && !this.plateauPickHeight && !(this.activeLayer === 'roads' && $('road-tool-mode').value === 'ramp')) {
      const settings = this.brushSettings(); const radius = settings.radius; const coreRadius = settings.coreRadius; const square = !settings.plateauMode && $('brush-shape').value === 'square';
      const drawProfileRing = (ringRadius, color, dash = []) => { if (ringRadius <= 0.15) return; ctx.setLineDash(dash); ctx.strokeStyle = color; ctx.beginPath(); if (square) ctx.rect(this.hover.x - ringRadius, this.hover.z - ringRadius, ringRadius * 2, ringRadius * 2); else ctx.arc(this.hover.x, this.hover.z, ringRadius, 0, Math.PI * 2); ctx.stroke(); };
      ctx.lineWidth = Math.max(.8, this.width / 600);
      if (settings.plateauMode) {
        if (settings.plateau.supportEnabled) drawProfileRing(radius, '#66df8bee');
        drawProfileRing(settings.plateau.slopeEndRadius, '#ffffffee');
        drawProfileRing(coreRadius, '#ffdc78ff', [Math.max(1.5, this.width / 512), Math.max(1.5, this.width / 512)]);
      } else if (settings.advanced) {
        drawProfileRing(radius, '#ffffffee');
        drawProfileRing(coreRadius, '#ffdc78ee', [Math.max(1.5, this.width / 512), Math.max(1.5, this.width / 512)]);
        const slopeEnd = coreRadius + settings.elevationProfile.slopeWidth;
        if (settings.elevationProfile.baseEnabled && slopeEnd > coreRadius + 0.05 && slopeEnd < radius - 0.05) drawProfileRing(slopeEnd, '#ff9b66ee', [Math.max(2, this.width / 384), Math.max(1, this.width / 640)]);
      } else {
        drawProfileRing(radius, '#ffffffee');
        if (coreRadius > 0.15 && coreRadius < radius - 0.05) drawProfileRing(coreRadius, '#ffdc78dd', [Math.max(1.5, this.width / 512), Math.max(1.5, this.width / 512)]);
      }
      ctx.setLineDash([]);
      if (this.lineStart) { ctx.strokeStyle = '#ffef9c'; ctx.beginPath(); ctx.moveTo(this.lineStart.x, this.lineStart.z); ctx.lineTo(this.hover.x, this.hover.z); ctx.stroke(); }
    }
  }

  applyZoom() {
    const zoom = Number($('zoom').value); $('zoom-value').textContent = `${zoom}%`; const requestedScale = zoom / 100; const minimumScale = 160 / Math.max(1, Math.min(this.width, this.length)); const scale = Math.max(requestedScale, minimumScale); const stage = $('canvas-stage'); stage.style.width = `${Math.round(this.width * scale)}px`; stage.style.height = `${Math.round(this.length * scale)}px`;
  }

  applyPreset() {
    const value = $('dimension-preset').value; if (value === 'custom') return; const [width, length] = value.split('x').map(Number); $('width').value = width; $('length').value = length; this.updateVoxelBudget(); this.updateMountainUi();
  }

  resizeFromInputs() {
    const newWidth = Number($('width').value); const newLength = Number($('length').value);
    if (![newWidth, newLength].every((value) => Number.isInteger(value) && value >= MIN_MAP_SIZE && value <= MAX_MAP_SIZE && value % 16 === 0)) { this.message(`Ancho y largo deben ser múltiplos de 16 entre ${MIN_MAP_SIZE} y ${MAX_MAP_SIZE}.`, true); return; }
    if (newWidth === this.width && newLength === this.length) return;
    if (!confirm(`Redimensionar de ${this.width}×${this.length} a ${newWidth}×${newLength}. Las capas se reescalarán por vecino más cercano.`)) return;
    const oldWidth = this.width; const oldLength = this.length;
    for (const name of Object.keys(LAYERS)) { const old = this.layers[name]; const next = new Uint8Array(newWidth * newLength); for (let z = 0; z < newLength; z += 1) { const sourceZ = Math.min(oldLength - 1, Math.round(z / Math.max(1, newLength - 1) * (oldLength - 1))); for (let x = 0; x < newWidth; x += 1) { const sourceX = Math.min(oldWidth - 1, Math.round(x / Math.max(1, newWidth - 1) * (oldWidth - 1))); next[z * newWidth + x] = old[sourceZ * oldWidth + sourceX]; } } this.layers[name] = next; }
    this.markers = this.markers.map((marker) => ({ ...marker, x: Math.round(marker.x / Math.max(1, oldWidth - 1) * (newWidth - 1)), z: Math.round(marker.z / Math.max(1, oldLength - 1) * (newLength - 1)) }));
    this.roadRamps = this.roadRamps.map((ramp) => ({ ...ramp, points: ramp.points.map((point) => ({ x: point.x / Math.max(1, oldWidth - 1) * (newWidth - 1), z: point.z / Math.max(1, oldLength - 1) * (newLength - 1) })) }));
    this.width = newWidth; this.length = newLength; this.playableBoundaryCache = null; this.playableBoundaryPathCache = null; this.canvas.width = newWidth; this.canvas.height = newLength; this.overlay.width = newWidth; this.overlay.height = newLength; this.undoStack.length = 0; this.redoStack.length = 0; this.applyZoom(); this.markDirty(); this.render(); this.renderMarkers(); this.updateSizeInfo(); this.updateHistory(); this.updateMountainUi(); this.updatePlateauUi(); this.renderRoadRampList();
  }

  updateSizeInfo() { $('project-size').textContent = `${this.width} × ${this.length} celdas`; $('width').value = this.width; $('length').value = this.length; }

  collectConfig() {
    const config = {
      name: $('project-name').value.trim(), width: this.width, length: this.length, schematic_height: Number($('schematic-height').value), min_height: Number($('min-height').value), max_height: Number($('max-height').value), sea_level: Number($('sea-level').value),
      height_modifier_range: Number($('modifier-range').value), shore_width: Number($('shore-width').value), max_walk_slope: Number($('max-walk-slope').value), surface_depth: Number($('surface-depth').value), data_version: Number($('data-version').value), seed: Number($('seed').value),
      mountain_border_enabled: $('mountain-border-enabled').checked, mountain_outer_width: Number($('mountain-outer-width').value), mountain_inner_transition: Number($('mountain-inner-transition').value), mountain_height: Number($('mountain-height').value), mountain_irregularity: Number($('mountain-irregularity').value), mountain_roughness: Number($('mountain-roughness').value), mountain_exit_width: Number($('mountain-exit-width').value), mountain_exit_transition: Number($('mountain-exit-transition').value), max_voxels: MAX_EXPORT_VOXELS,
    };
    if (!/^[a-zA-Z0-9_-]{1,60}$/.test(config.name)) throw new Error('El nombre solo admite letras, números, guion y guion bajo.');
    if (!(config.min_height < config.sea_level && config.sea_level < config.max_height && config.max_height < config.schematic_height)) throw new Error('Debe cumplirse: altura mínima < agua < altura máxima < altura schematic.');
    return config;
  }

  projectDocument() {
    const layers = {}; for (const [name, array] of Object.entries(this.layers)) layers[name] = { encoding: 'rle-u8', data: encodeRle(array) };
    return { format: 'jkr-terrain-project', version: 2, config: this.collectConfig(), layers, markers: structuredClone(this.markers), road_ramps: structuredClone(this.roadRamps) };
  }

  saveProject() {
    try { const project = this.projectDocument(); downloadJson(`${project.config.name}.jkrterrain.json`, project); this.dirty = false; $('dirty-badge').textContent = 'Guardado'; $('dirty-badge').className = 'badge ok'; this.message('Proyecto guardado.'); }
    catch (error) { this.message(error.message, true); }
  }

  async loadProject(event) {
    const file = event.target.files?.[0]; if (!file) return;
    try {
      const project = JSON.parse(await file.text()); if (project.format !== 'jkr-terrain-project' || project.version !== 2) throw new Error('Formato de proyecto no compatible.');
      const config = project.config; const width = Number(config.width); const length = Number(config.length); const expected = width * length;
      if (width < MIN_MAP_SIZE || width > MAX_MAP_SIZE || length < MIN_MAP_SIZE || length > MAX_MAP_SIZE || width % 16 || length % 16) throw new Error('Dimensiones inválidas.');
      const decoded = {}; for (const name of Object.keys(LAYERS)) { if (!project.layers?.[name]) throw new Error(`Falta la capa ${name}.`); decoded[name] = decodeRle(project.layers[name].data, expected); }
      this.width = width; this.length = length; this.layers = decoded; this.markers = Array.isArray(project.markers) ? project.markers : []; this.roadRamps = Array.isArray(project.road_ramps) ? project.road_ramps : []; this.roadRampDraft = []; this.roadRampEditingId = null; this.selectedRoadRampId = null; this.playableBoundaryCache = null; this.playableBoundaryPathCache = null; for (const name of Object.keys(LAYERS)) { this.visibility[name] = true; this.locked[name] = false; } this.buildLayerList();
      this.canvas.width = width; this.canvas.height = length; this.overlay.width = width; this.overlay.height = length; this.setConfigInputs(config); this.undoStack.length = 0; this.redoStack.length = 0; this.applyZoom(); this.render(); this.renderMarkers(); this.updateSizeInfo(); this.updateHistory(); this.updatePlateauUi(); this.renderRoadRampList(); this.dirty = false; $('dirty-badge').textContent = 'Cargado'; $('dirty-badge').className = 'badge ok'; this.message(`Proyecto ${file.name} cargado.`);
    } catch (error) { this.message(`No se pudo abrir: ${error.message}`, true); }
    finally { event.target.value = ''; }
  }

  setConfigInputs(config) {
    const mapping = { name: 'project-name', seed: 'seed', width: 'width', length: 'length', schematic_height: 'schematic-height', min_height: 'min-height', max_height: 'max-height', sea_level: 'sea-level', height_modifier_range: 'modifier-range', shore_width: 'shore-width', max_walk_slope: 'max-walk-slope', surface_depth: 'surface-depth', data_version: 'data-version', mountain_outer_width: 'mountain-outer-width', mountain_inner_transition: 'mountain-inner-transition', mountain_height: 'mountain-height', mountain_irregularity: 'mountain-irregularity', mountain_roughness: 'mountain-roughness', mountain_exit_width: 'mountain-exit-width', mountain_exit_transition: 'mountain-exit-transition' };
    for (const [key, id] of Object.entries(mapping)) if (config[key] !== undefined) $(id).value = config[key];
    $('mountain-border-enabled').checked = Boolean(config.mountain_border_enabled); this.updateVoxelBudget(); this.updateMountainUi();
  }

  newProject() {
    if (this.dirty && !confirm('Crear un proyecto nuevo descartará los cambios no guardados.')) return;
    this.width = Number($('width').value) || 256; this.length = Number($('length').value) || 256; this.playableBoundaryCache = null; this.playableBoundaryPathCache = null; this.initializeLayers(); this.buildLayerList(); this.markers = []; this.roadRamps = []; this.roadRampDraft = []; this.roadRampEditingId = null; this.selectedRoadRampId = null; this.undoStack.length = 0; this.redoStack.length = 0; this.canvas.width = this.width; this.canvas.height = this.length; this.overlay.width = this.width; this.overlay.height = this.length; this.applyZoom(); this.markDirty(); this.render(); this.renderMarkers(); this.updateSizeInfo(); this.updateHistory(); this.updateMountainUi(); this.updatePlateauUi(); this.renderRoadRampList(); this.message('Proyecto nuevo creado.');
  }

  async compile(exportSchematic) {
    let project; try { project = this.projectDocument(); } catch (error) { this.message(error.message, true); return; }
    const button = exportSchematic ? $('export-schematic') : $('compile-preview'); const original = button.textContent; button.disabled = true; button.textContent = exportSchematic ? 'Exportando…' : 'Compilando…'; this.message('Compilando capas…');
    try {
      const response = await fetch('/api/compile', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ project, export_schematic: exportSchematic }) });
      const payload = await response.json(); if (!response.ok) throw new Error(typeof payload.detail === 'string' ? payload.detail : JSON.stringify(payload.detail));
      this.compiledFiles = payload.files; this.renderValidation(payload.validation); this.renderDownloads(payload.files); this.selectPreview('preview'); this.message(exportSchematic ? 'Schematic generado correctamente.' : 'Vista compilada correctamente.');
    } catch (error) { this.message(`Error de compilación: ${error.message}`, true); }
    finally { button.disabled = false; button.textContent = original; }
  }

  renderValidation(validation) {
    const status = $('validation-status'); status.textContent = validation.status === 'ok' ? 'Aprobada' : 'Con errores'; status.className = `badge ${validation.status === 'ok' ? 'ok' : 'error'}`;
    const borderText = validation.mountain_border?.enabled ? ` · borde: ${validation.mountain_border.strong_cells.toLocaleString('es-CL')} celdas fuertes` : '';
    const rampText = validation.road_ramps?.count ? ` · rampas ${validation.road_ramps.valid}/${validation.road_ramps.count}` : '';
    $('validation-summary').textContent = `${validation.detected_exits.length} salida(s) detectada(s) · ${validation.road_components} componente(s) vial(es) · ${(validation.walkable_ratio * 100).toFixed(1)}% transitable · salto vial máximo ${validation.maximum_road_step}${rampText}${borderText}.`;
    const list = $('validation-issues'); list.replaceChildren();
    if (!validation.issues.length) { const ok = document.createElement('div'); ok.className = 'issue'; ok.textContent = 'No se detectaron problemas estructurales principales.'; list.append(ok); }
    for (const issue of validation.issues) { const item = document.createElement('div'); item.className = `issue ${issue.severity}`; item.textContent = issue.message; list.append(item); }
  }

  renderDownloads(files) {
    const links = $('download-links'); links.replaceChildren(); const labels = { preview: 'Vista PNG', heightmap: 'Heightmap', slope: 'Pendiente', walkability: 'Transitabilidad', terrain3d: 'Datos de vista 3D', voxel3d: 'Manifiesto de vista Minecraft', validation: 'Validación JSON', metadata: 'Metadatos', schematic: 'Descargar .schem' };
    for (const [key, url] of Object.entries(files)) { const anchor = document.createElement('a'); anchor.href = url; anchor.textContent = labels[key] || key; if (!url.endsWith('.png')) anchor.download = ''; links.append(anchor); }
  }

  selectPreview(key) {
    this.activePreview = key;
    document.querySelectorAll('[data-preview]').forEach((button) => button.classList.toggle('active', button.dataset.preview === key));
    const image = $('result-preview'); const view3d = $('terrain-3d-view'); const voxelView = $('voxel-3d-view'); const url = this.compiledFiles?.[key];
    const is3d = key === 'terrain3d'; const isVoxel = key === 'voxel3d';
    if (!is3d) this.viewer3d.setExpanded(false); if (!isVoxel) this.voxelViewer.setExpanded(false);
    image.hidden = is3d || isVoxel; view3d.hidden = !is3d; voxelView.hidden = !isVoxel;
    if (is3d) {
      if (url) this.viewer3d.load(url); else $('terrain-3d-status').textContent = 'Compila el proyecto para generar la vista 3D.';
    } else if (isVoxel) {
      if (url) this.voxelViewer.load(url); else $('voxel-3d-status').textContent = 'Compila el proyecto para generar la vista Minecraft.';
    } else if (url) image.src = `${url}?t=${Date.now()}`;
  }

  updateMountainUi() {
    const enabled = $('mountain-border-enabled').checked;
    $('mountain-settings').classList.toggle('disabled-group', !enabled);
    $('mountain-settings').querySelectorAll('input').forEach((input) => { input.disabled = !enabled; });
    const status = $('mountain-status'); status.textContent = enabled ? 'Activado' : 'Desactivado'; status.className = `badge ${enabled ? 'ok' : 'neutral'}`;
    const margin = Number($('mountain-outer-width').value) || 0; const usableWidth = this.width - margin * 2; const usableLength = this.length - margin * 2;
    $('mountain-margin-info').textContent = enabled ? `Margen propuesto: ${margin} bloques · zona central aproximada ${Math.max(0, usableWidth)} × ${Math.max(0, usableLength)}.` : 'Activa el borde para generar la cordillera durante la compilación.';
  }

  prepareMountainMargin() {
    const margin = Math.round(Number($('mountain-outer-width').value));
    if (!Number.isInteger(margin) || margin < 4 || margin * 2 >= Math.min(this.width, this.length) - 16) { this.message('El margen debe dejar al menos 16 bloques de zona central.', true); return; }
    if (!confirm(`Se marcarán como no jugables ${margin} bloques alrededor del lienzo. El interior existente se conservará. ¿Continuar?`)) return;
    const layer = this.layers.playable; const changes = [];
    for (let z = 0; z < this.length; z += 1) for (let x = 0; x < this.width; x += 1) {
      if (x >= margin && x < this.width - margin && z >= margin && z < this.length - margin) continue;
      const index = z * this.width + x; if (layer[index] !== 0) { changes.push([index, layer[index], 0]); layer[index] = 0; }
    }
    if (changes.length) this.pushHistory({ type: 'cells', layer: 'playable', changes });
    else this.markDirty();
    this.playableBoundaryCache = null; this.playableBoundaryPathCache = null; $('mountain-border-enabled').checked = true; this.updateMountainUi(); this.setActiveLayer('playable'); this.render(); this.renderMarkers(); this.message(`Margen montañoso de ${margin} bloques preparado. Coloca marcadores de salida y compila la vista.`);
  }

  drawMountainGuide(ctx) {
    const playable = this.layers.playable; if (!playable?.length) return;
    const enabled = $('mountain-border-enabled').checked; const lineWidth = Math.max(0.7, this.width / 700);
    ctx.save(); ctx.lineWidth = lineWidth; ctx.strokeStyle = enabled ? '#ffb45eee' : '#d97d7dcc';
    if (!this.playableBoundaryPathCache) {
      const path = new Path2D();
      for (let z = 0; z < this.length; z += 1) for (let x = 0; x < this.width; x += 1) {
        const index = z * this.width + x; if (playable[index] < 128) continue;
        if (z === 0 || playable[index - this.width] < 128) { path.moveTo(x, z); path.lineTo(x + 1, z); }
        if (z === this.length - 1 || playable[index + this.width] < 128) { path.moveTo(x, z + 1); path.lineTo(x + 1, z + 1); }
        if (x === 0 || playable[index - 1] < 128) { path.moveTo(x, z); path.lineTo(x, z + 1); }
        if (x === this.width - 1 || playable[index + 1] < 128) { path.moveTo(x + 1, z); path.lineTo(x + 1, z + 1); }
      }
      this.playableBoundaryPathCache = path;
    }
    ctx.stroke(this.playableBoundaryPathCache);
    if (enabled) {
      ctx.setLineDash([3, 2]); ctx.strokeStyle = '#75b9ffcc';
      for (const marker of this.markers.filter((item) => item.type === 'exit')) { ctx.beginPath(); ctx.arc(marker.x + .5, marker.z + .5, Math.max(2, Number($('mountain-exit-width').value) / 2), 0, Math.PI * 2); ctx.stroke(); }
    }
    ctx.restore();
  }

  updateVoxelBudget() {
    const width = Number($('width').value) || 0; const length = Number($('length').value) || 0; const height = Number($('schematic-height').value) || 0; const voxels = width * length * height; const budget = $('voxel-budget');
    const level = voxels > MAX_EXPORT_VOXELS ? 'error' : voxels > EXPORT_WARNING_VOXELS ? 'warning' : 'ok';
    const suffix = level === 'error' ? ' Supera el límite de exportación.' : level === 'warning' ? ' Exportación grande: puede tardar y generar un archivo pesado.' : ' Volumen dentro del rango normal.';
    budget.textContent = `Volumen de exportación: ${voxels.toLocaleString('es-CL')} bloques. Límite: ${MAX_EXPORT_VOXELS.toLocaleString('es-CL')}.${suffix}`;
    budget.classList.toggle('warning', level === 'warning'); budget.classList.toggle('error', level === 'error');
  }

  markDirty() { this.dirty = true; $('dirty-badge').textContent = 'Sin guardar'; $('dirty-badge').className = 'badge'; }
  message(text, error = false) { $('editor-message').textContent = text; $('editor-message').style.color = error ? '#ff9a9a' : ''; }
}

const help = await initializeHelp();
const editor = new TerrainEditor(help);
window.terrainEditor = editor;

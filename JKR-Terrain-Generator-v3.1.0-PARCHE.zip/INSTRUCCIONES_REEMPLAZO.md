# Instalación de JKR Terrain Generator v3.1.0

## Parche sobre v3.0.0

Coloca `JKR-Terrain-Generator-v3.1.0-PARCHE.zip` en la raíz del proyecto y ejecuta:

```bash
unzip -o JKR-Terrain-Generator-v3.1.0-PARCHE.zip
rm JKR-Terrain-Generator-v3.1.0-PARCHE.zip
docker compose down
docker compose up -d --build
docker compose logs --tail=100
```

Después realiza una recarga forzada del navegador (`Ctrl+F5`).

Los proyectos anteriores siguen abriendo normalmente. Las rampas creadas en v3.0.0 mantienen el suavizado lateral desactivado para conservar su geometría; al editarlas puedes activar los nuevos controles.

## Proyecto completo

Extrae `JKR-Terrain-Generator-v3.1.0-COMPLETO.zip` en una carpeta nueva y ejecuta `docker compose up -d --build`.

## Costados suavizados

1. Selecciona **Caminos** y **Crear o editar rampa**.
2. Activa **Suavizar costados de la rampa**.
3. Ajusta **Pendiente lateral 1:X**. Un valor 1:2 usa aproximadamente dos bloques horizontales por bloque vertical.
4. Usa **Anchura lateral máxima** para limitar estrictamente el terreno afectado.
5. Ajusta **Redondez lateral** para pasar de una caída lineal a una unión redondeada.
6. Activa **Adaptarse al terreno** para responder a desniveles locales; desactívalo para un terraplén más simétrico.
7. Finaliza la rampa, compila y revísala en la Vista Minecraft.

# Instalación de JKR Terrain Generator v2.9.0

## Proyecto completo

1. Detén el contenedor anterior.
2. Conserva tus proyectos `*.jkrterrain.json`, schematics y la carpeta `output/` si contiene resultados importantes.
3. Extrae `JKR-Terrain-Generator-v2.9.0-COMPLETO.zip` en una carpeta nueva.
4. Ejecuta:

```bash
docker compose up -d --build
```

5. Abre `http://localhost:8080`.

## Actualización desde v2.8.0

Extrae `JKR-Terrain-Generator-v2.9.0-PARCHE.zip` directamente sobre la raíz de la v2.8.0 y acepta reemplazar archivos. No es necesario borrar archivos.

Los proyectos de formato v2 siguen siendo compatibles. La modificación cambia la herramienta de edición, no el formato de la capa `height_base`.

## Corrección crítica de mesetas

La v2.9.0 elimina por completo el uso de alturas vecinas al construir la base del borde montañoso. Después de actualizar, vuelve a pulsar **Compilar vista**: el montículo verde generado durante la compilación desaparecerá sin tener que repintar la meseta, porque ese halo no estaba almacenado en la capa editable.

Con **Generar soporte exterior** apagado, la meseta solo puede modificar su radio plano y la anchura de pendiente configurada. El borde montañoso no puede difundirla hacia el interior del mapa.

## Nueva herramienta de Altura base

1. Selecciona **Altura base**.
2. Escribe la **Altura de la meseta (Y)**.
3. Define el **Radio de la meseta**.
4. Define la **Anchura de la pendiente**.
5. Pinta o arrastra sobre el lienzo.

El círculo amarillo es la superficie plana. El círculo blanco marca el final exacto de la pendiente. Con **Generar soporte exterior** activado aparece un tercer círculo verde que delimita exclusivamente la falda de césped.

- **Anchura del soporte:** radio adicional hacia afuera.
- **Altura del soporte:** porcentaje de elevación que conserva junto a la meseta.

Con el soporte apagado no se modifica ninguna celda fuera del círculo blanco.

Usa **Tomar del terreno** y después haz clic sobre una plataforma existente para copiar su altura.

## Compilación limpia

Caminos y zonas reservadas ya no alteran alturas. Los antiguos campos `road_fit_width` y `reserved_fit_width` se aceptan para compatibilidad, pero no tienen efecto.

## Modificador de altura

El pincel avanzado anterior continúa disponible en **Modificador de altura** para retoques, irregularidades y cambios progresivos.

## Presets

Los presets de herramienta guardan tanto la configuración simple de meseta como la configuración del pincel de modificador. Permanecen asociados al navegador y a la dirección del editor.

## Importante al actualizar desde v2.8.0

Después de reconstruir el contenedor, abre el proyecto y pulsa **Compilar vista** otra vez. La v2.9.0 elimina el último acoplamiento entre la altura de una meseta y la transición interior del borde montañoso. No es necesario volver a pintar una meseta cuyo halo solo aparecía al compilar.

# Validación de la entrega v2.9.0

## Pruebas automáticas

Ejecutadas con:

```bash
pytest -q
```

Resultado: `41 passed`.

Se comprobó:

- API de salud y compilación v2.9.0;
- perfil de meseta con núcleo completamente plano y pendiente limitada;
- plataforma abrupta cuando la pendiente vale 0;
- conversión entre altura Y y valor de la capa;
- separación visual entre Herramienta de meseta y pincel avanzado;
- presencia de los círculos de meseta, pendiente y soporte exterior opcional;
- presets, mapas grandes, borde montañoso y vistas 3D existentes;
- caminos y zonas reservadas sin cambios ocultos de altura;
- soporte exterior con radio, altura y recorte exactos;
- meseta alta dentro de la transición interior del borde sin propagación hacia el césped vecino;
- preservación exacta de todas las celdas donde la máscara montañosa y los corredores valen cero;
- generación voxel y correspondencia con el schematic.

## Reproducción del halo corregido

Se compiló una meseta central abrupta, con soporte exterior apagado y borde montañoso activo. En la v2.7.0 el filtro modificaba 2.052 celdas del anillo exterior y añadía hasta 14 bloques de altura pese a que la máscara montañosa valía cero. La v2.9.0 añade además una prueba más exigente dentro de la propia máscara montañosa: al comparar el mapa con y sin meseta, 0 celdas exteriores a la huella de la meseta cambian.

## Validación de sintaxis

```bash
python -m compileall -q app scripts tests
node --check app/static/app.js
node --check app/static/plateau-tool.js
node --check app/static/brush-profile.js
node --check app/static/config-help.js
node --check app/static/terrain-viewer.js
node --check app/static/voxel-viewer.js
```

## Revisión de interfaz

Se comprobó mediante pruebas estáticas y de lógica JavaScript que:

- `Altura base` contiene el soporte exterior opcional;
- los controles antiguos de ajuste de caminos y zonas reservadas ya no aparecen;
- el soporte apagado termina exactamente en el círculo blanco, también en el resultado compilado;
- el soporte activado añade una tercera zona con límite verde;
- los presets guardan anchura, altura y estado del soporte;
- no hay errores de sintaxis en los módulos JavaScript.

Chromium bloqueó por política administrativa la navegación a direcciones locales y dominios interceptados en este entorno, por lo que no se afirma una prueba visual automatizada completa. Docker tampoco está instalado en el entorno de construcción, por lo que no se ejecutó `docker compose build`.

## Regresión crítica v2.9.0: meseta dentro de la transición montañosa

Se compilaron dos mapas idénticos con borde montañoso activo y transición interior de 32 bloques. En uno se añadió una meseta abrupta dentro de esa transición y en el otro no. Se compararon todas las celdas exteriores a la huella exacta de la meseta: el resultado debe ser idéntico en ambos mapas. Esto comprueba que ni el borde, ni su suavizado, ni los corredores pueden propagar la altura de la meseta al césped vecino.
